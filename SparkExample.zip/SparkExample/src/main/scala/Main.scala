import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.rdd.RDD

import scala.io._

object Main {
  def main(args: Array[String]) {                
    val sparkConf = new SparkConf().setAppName("Example").setMaster("local[16]")
    val ctx = new SparkContext(sparkConf)        
    
    val list = List(1, 2, 3)
    
    val bigList = ctx.parallelize(list)
    
    //bigList.foreach(x => println(x))
    
    //val doubleBigList = bigList.map(x => x * 2)    
    //doubleBigList.foreach(x => println(x))
    //val smallList = bigList.collect.toList 
    //println(smallList)
    
    //val list2 = List(1 -> "one", 2 -> "two", 3 -> "three")    
    //val bigList2 = ctx.parallelize(list2)    
    
    //val list3 = List(1 -> "1", 2 -> "2", 3 -> "3")
    //val bigList3 = ctx.parallelize(list3)
    
    //val joinedList = bigList2.join(bigList3)
    //joinedList.foreach(x => println(x))
    
    //val list4 = List(1 -> "one", 2 -> "two", 3 -> "three", 3 -> "trois")
    //val groups = list4.groupBy(x => x._1)
    //groups.foreach(x => println(x))
    
    // read from file
    //val file = getClass.getResource("example.csv").getPath
    //val rdd = ctx.textFile(file)    
    //println(rdd.count)
        
    //val newrdd = rdd.map(x => x.split(","))
    //val rdd2 = newrdd.map(x => (x(0), x(1)))
    //rdd2.foreach(x => println(x))     
  }     
}
