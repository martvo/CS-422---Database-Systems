# CS422-Project1

In this project you have to first implement three different data layouts and three different execution models. Subsequently, you have to execute queries testing different combinations of data layouts and execution models.

This repository provides the skeleton codebase on which you will add your implementation. Test cases that will allow you to check the functionality of your code as well as measure the efficiency of your implementation are also provided.

## Warning!!
###Keep in mind that we will test your code automatically. We will harshly penalize implementations that change the original skeleton code and implementations which are specific to the given datasets.
