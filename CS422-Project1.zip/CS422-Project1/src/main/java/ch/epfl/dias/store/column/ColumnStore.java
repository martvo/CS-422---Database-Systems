package ch.epfl.dias.store.column;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import ch.epfl.dias.store.DataType;
import ch.epfl.dias.store.Store;
import ch.epfl.dias.store.column.DBColumn;


public class ColumnStore extends Store {
	
	public List<DBColumn> columnStore;
	public DataType[] schema;
	public String filename;
	public String delimiter;
	public boolean lateMaterialization;
	public int sizeOfStore;

	public ColumnStore(DataType[] schema, String filename, String delimiter) {
		this(schema, filename, delimiter, false);
	}

	public ColumnStore(DataType[] schema, String filename, String delimiter, boolean lateMaterialization) {
		columnStore = new ArrayList<DBColumn>();
		this.schema = schema;
		this.filename = filename;
		this.delimiter = delimiter;
		this.lateMaterialization = lateMaterialization;
	}

	@Override
	public void load() throws IOException {
		
		//initialize Path object
		Path path = Paths.get(filename);
		// List to store the columns of data, will be turned to Array later
		List<List<Object>> columns = new ArrayList<List<Object>>();
		// fill the List with Lists
		for (int i = 0; i < schema.length; i++) {
			columns.add(new ArrayList<Object>());
		}

		//create file

		// Path createdFilePath = Files.createFile(path);
		// System.out.println("File Created at Path : " + createdFilePath);
		List<String> strings = Files.readAllLines(path);
		
		//InputStream in_stream = Files.newInputStream(path);
		//BufferedReader reader = new BufferedReader(in_stream);
		//System.out.println("Read lines: \n" + strings);
		
		for (int i = 0; i < strings.size(); i++) {
			String[] parts = strings.get(i).split(this.delimiter);
			if (parts.length > schema.length) {
				throw new IOException("Count of columns doesn't match schema");
			}
			for (int j = 0; j < schema.length; j++) {
				Object element = parse_element(parts[j], this.schema[j]);
				columns.get(j).add(element);
			}
		}
		// System.out.println(columns);
		// Turn ArrayList into DBColumn Array
		for (int i = 0; i < columns.size(); i++) {
			Object[] columnArray = new Object[columns.get(i).size()];
			columns.get(i).toArray(columnArray);
			// System.out.println(column_array[2]);
			DBColumn dbcolumn = new DBColumn(columnArray, this.schema[i]);
			if (lateMaterialization) {
				dbcolumn.setLateMaterialization();
			}
			this.columnStore.add(dbcolumn);
		}
		sizeOfStore = columns.size();
	}
	
	
	public Object parse_element(String element, DataType type) {
		Object outElement = null;
		switch (type) {
			case INT:
				outElement = Integer.parseInt(element);
				break;	
			case DOUBLE:
				outElement = Double.parseDouble(element);
				break;
			case BOOLEAN:
				outElement = Boolean.parseBoolean(element);
				break;	
			case STRING:
				outElement = element;
				break;
		}
		return outElement;
	}

	@Override
	public DBColumn[] getColumns(int[] columnsToGet) {
		// Returns all columns if length of columnsToGet == 0
		if (columnsToGet.length == 0) {
			int[] cols = new int[schema.length];
			for (int i = 0; i < schema.length; i++) {
				cols[i] = i;
			}
			columnsToGet = cols;
		}
		DBColumn[] outColumns = new DBColumn[columnsToGet.length];
		for (int i = 0; i < columnsToGet.length; i++) {
			if (columnsToGet[i] >= columnStore.size()) {
				return null;
			} else {
				outColumns[i] = this.columnStore.get(columnsToGet[i]);
			}
		}
		if (lateMaterialization && columnsToGet.length >= columnStore.size()) {
			for (DBColumn column : outColumns) {
				column.resetIndices();
			}
		}
		
		return outColumns;
	}
}
