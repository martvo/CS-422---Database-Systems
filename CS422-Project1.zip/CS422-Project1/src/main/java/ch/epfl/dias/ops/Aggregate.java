package ch.epfl.dias.ops;

public enum Aggregate   {
    COUNT,SUM,MIN,MAX,AVG
}

