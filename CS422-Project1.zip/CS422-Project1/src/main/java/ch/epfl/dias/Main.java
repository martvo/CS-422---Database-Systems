package ch.epfl.dias;

import java.io.IOException;

import ch.epfl.dias.ops.Aggregate;
import ch.epfl.dias.ops.BinaryOp;
import ch.epfl.dias.ops.volcano.HashJoin;
import ch.epfl.dias.ops.volcano.ProjectAggregate;
import ch.epfl.dias.ops.volcano.Select;
import ch.epfl.dias.store.DataType;
import ch.epfl.dias.store.PAX.PAXStore;
import ch.epfl.dias.store.column.ColumnStore;
import ch.epfl.dias.store.column.DBColumn;
import ch.epfl.dias.store.row.DBTuple;
import ch.epfl.dias.store.row.RowStore;

import ch.epfl.dias.tests.*;



public class Main {

	public static void main(String[] args) throws IOException {

		DataType[] schema = new DataType[] { DataType.INT, DataType.INT, DataType.INT, DataType.INT, DataType.INT,
				DataType.INT, DataType.INT, DataType.INT, DataType.INT, DataType.INT };

		DataType[] orderSchema = new DataType[] { DataType.INT, DataType.INT, DataType.STRING, DataType.DOUBLE,
				DataType.STRING, DataType.STRING, DataType.STRING, DataType.INT, DataType.STRING };

		schema = new DataType[] { DataType.INT, DataType.INT, DataType.INT, DataType.INT, DataType.INT, DataType.INT,
				DataType.INT, DataType.INT, DataType.INT, DataType.INT };
		
		DataType[] lineitemSchema = new DataType[]{ DataType.INT, DataType.INT, DataType.INT, DataType.INT,
				DataType.DOUBLE, DataType.DOUBLE, DataType.DOUBLE, DataType.DOUBLE, DataType.STRING, DataType.STRING, DataType.STRING,
				DataType.STRING, DataType.STRING, DataType.STRING, DataType.STRING, DataType.STRING};
	
		
		if (args.length > 0) {
			switch(args[0]) {
				case "NSMTuple":
					NSMTuple.run();
					break;
				case "NSMPAXTuple":
					NSMPAXTuple.run();
					break;
				case "DSMColumn":
					DSMColumn.run();
					break;
				case "DSMVector":
					DSMVector.run();
					break;
				case "DSMLateMat":
					DSMLateMat.run();
				default:
					System.out.println("Use eighter 'NSMTuple', 'NSMPAXTuple', 'DSMColumn', 'DSMVector', 'DSMLateMat' as argument");
			}
		} else {
			System.out.println("Note a Test File!");
		}
		
	}
}
