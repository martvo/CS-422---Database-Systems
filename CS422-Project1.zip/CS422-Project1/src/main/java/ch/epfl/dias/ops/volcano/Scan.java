package ch.epfl.dias.ops.volcano;

import ch.epfl.dias.ops.BinaryOp;
import ch.epfl.dias.store.DataType;
import ch.epfl.dias.store.Store;
import ch.epfl.dias.store.row.DBTuple;

public class Scan implements VolcanoOperator {

	public Store store;
	public int currentRowIndex;

	public Scan(Store store) {
		this.store = store;
	}

	@Override
	public void open() {
		this.currentRowIndex = 0;
	}

	@Override
	public DBTuple next() {
		DBTuple nextOutTuple = store.getRow(currentRowIndex);
		currentRowIndex++;
		return nextOutTuple;
	}

	@Override
	public void close() {
		currentRowIndex = 0;
		// store = null;
	}
}