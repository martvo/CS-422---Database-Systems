package ch.epfl.dias.ops.columnar;

import java.util.ArrayList;
import java.util.List;

import ch.epfl.dias.ops.BinaryOp;
import ch.epfl.dias.store.column.DBColumn;

public class Select implements ColumnarOperator {

	ColumnarOperator child;
	BinaryOp op;
	int fieldNo;
	int value;

	public Select(ColumnarOperator child, BinaryOp op, int fieldNo, int value) {
		this.child = child;
		this.op = op;
		this.fieldNo = fieldNo;
		this.value = value;
		// System.out.println("Query is: column " + fieldNo + " " + op + " " + value);
	}
	
	public void printIndices(DBColumn[] columns) {
		for (Integer i : columns[0].getIndices()) {
			System.out.print(i + " | ");
		}
		System.out.println();
	}

	@Override
	public DBColumn[] execute() {
		DBColumn[] childResult = this.child.execute();
		DBColumn[] outColumns = new DBColumn[childResult.length];
		// System.out.println("In select");
		// printIndices(childResult);
		List<Integer> filteredIndexes = new ArrayList<Integer>();
		filteredIndexes = filterIndexes(childResult[fieldNo], op, value);
		// System.out.println("Selected indicies: " + filteredIndexes);
		
		
		if (childResult[0].lateMaterialization) {
			// Doesn't matter where the for loop is, as earlyMateralization will
			// Create new DBColumn's anyway
			
			for (DBColumn col : childResult) {
				
				col.filterIndices(filteredIndexes.toArray(new Integer[0]));
			}
			// System.out.println("After filtering Idicies:");
			// printIndices(childResult);
			// System.out.println(childResult[0].getAsInteger().length);
			// System.out.println(childResult[0].elements.length);
			return childResult;
		} else {
			for (int i = 0; i < childResult.length; i++) {
				DBColumn column = childResult[i];
				Object[] fileteredColumn = new Object[filteredIndexes.size()];
				Object[] tmpColumn;
				switch (column.getType()) {
					case INT:
						tmpColumn = column.getAsInteger();
						// System.out.println("Length of col: " + tmpColumn.length);
						break;
					case DOUBLE:
						tmpColumn = column.getAsDouble();
						break;
					case BOOLEAN:
						tmpColumn = column.getAsBoolean();
						break;
					case STRING:
						tmpColumn = column.getAsString();
						break;
					default:
						tmpColumn = null;
						break;
				}
				for (int j = 0; j < filteredIndexes.size(); j++) {
					fileteredColumn[j] = tmpColumn[filteredIndexes.get(j)];
				}
				outColumns[i] = new DBColumn(fileteredColumn, childResult[i].getType());
			}
			/*
			System.out.println("Length of filteredColumn: " + filteredIndexes.size());
			System.out.println("Length of column index: " + outColumns[0].getIndices().length);
			System.out.println("They are:");
			for (int x : outColumns[0].getIndices()) {
				System.out.print(x);
			}
			System.out.println();
			*/
			return outColumns;
		}
	}
	
	public List<Integer> filterIndexes(DBColumn column, BinaryOp op, int value) {
		List<Integer> indexes = new ArrayList<Integer>();
		int i = 0;
		for (Integer currentValue : column.getAsInteger()) {
			switch (op) {
				case LT:
					if (currentValue < value) {
						indexes.add(i);
					}
					break;
				case LE:
					if (currentValue <= value) {
						indexes.add(i);
					}		
					break;
				case EQ:
					if (currentValue == value) {
						indexes.add(i);
					}
					break;
				case NE:
					if (currentValue != value) {
						indexes.add(i);
					}
					break;
				case GT:
					if (currentValue > value) {
						indexes.add(i);
					}
					break;
				case GE:
					if (currentValue >= value) {
						indexes.add(i);
					}
					break;
				default:
					break;
			}
			i++;
		}
		return indexes;
	}
}
