package ch.epfl.dias.ops.volcano;

import ch.epfl.dias.ops.BinaryOp;
import ch.epfl.dias.store.DataType;
import ch.epfl.dias.store.row.DBTuple;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

public class HashJoin implements VolcanoOperator {

	public VolcanoOperator leftChild;
	public VolcanoOperator rightChild;
	public int leftFieldNo;
	public int rightFieldNo;
	public HashMap<Object, ArrayList<DBTuple>> leftHashTable;
	public DBTuple rightChildResult;
	public Iterator<DBTuple> hashedArrayIterator;
	public List<DBTuple> matchingArray = new ArrayList<DBTuple>();

	public HashJoin(VolcanoOperator leftChild, VolcanoOperator rightChild, int leftFieldNo, int rightFieldNo) {
		this.leftChild = leftChild;
		this.rightChild = rightChild;
		this.leftFieldNo = leftFieldNo;
		this.rightFieldNo = rightFieldNo;
		this.leftHashTable = new HashMap<Object, ArrayList<DBTuple>>();
	}

	@Override
	public void open() {
		leftChild.open();
		rightChild.open();
		creatHashtable(leftChild, leftFieldNo);
		rightChildResult = rightChild.next();
		setHashtableIeterator(rightChildResult);
	}
	
	public void creatHashtable(VolcanoOperator leftChild, int leftFieldNo) {
		DBTuple leftChildResult = leftChild.next();
		while(!leftChildResult.eof) {
			Object leftValue = leftChildResult.fields[leftFieldNo];
			if (leftHashTable.get(leftValue) != null) {
				leftHashTable.get(leftValue).add(leftChildResult);
			} else {
				leftHashTable.put(leftValue, new ArrayList<DBTuple>());
				leftHashTable.get(leftValue).add(leftChildResult);
			}
			leftChildResult = leftChild.next();
		}
	}
	
	public void setHashtableIeterator(DBTuple rightChildResult) {
		Object rightValue = rightChildResult.fields[rightFieldNo];
		if (leftHashTable.get(rightValue) != null) {
			matchingArray = leftHashTable.get(rightValue);
			hashedArrayIterator = matchingArray.iterator();
		} else {
			hashedArrayIterator = Collections.emptyIterator();
		}
	}

	@Override
	public DBTuple next() {
		while(!rightChildResult.eof) {
			if (hashedArrayIterator.hasNext()) {
				return joinTuples(hashedArrayIterator.next(), rightChildResult);
			} else {
				rightChildResult = rightChild.next();
				if (!rightChildResult.eof) {
					setHashtableIeterator(rightChildResult);
				}
			}
		}
		return rightChildResult;
	}
	
	public DBTuple joinTuples(DBTuple leftTuple, DBTuple righTuple) {
		DataType[] types = new DataType[leftTuple.types.length + righTuple.types.length];
		Object[] fields = new Object[leftTuple.fields.length + righTuple.types.length];
		
		for (int i = 0; i < leftTuple.fields.length; i++) {
			fields[i] = leftTuple.fields[i];
			types[i] = leftTuple.types[i];
		}
		
		int index = leftTuple.fields.length;
		for (int i = 0; i < righTuple.fields.length; i++) {
			fields[index] = righTuple.fields[i];
			types[index] = righTuple.types[i];
			index++;
		}
		return new DBTuple(fields, types);
	}

	@Override
	public void close() {
		leftChild.close();
		rightChild.close();
	}
}
