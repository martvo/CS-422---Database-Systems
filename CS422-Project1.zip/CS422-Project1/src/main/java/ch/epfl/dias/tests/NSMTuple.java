package ch.epfl.dias.tests;

import java.io.IOException;

import ch.epfl.dias.ops.Aggregate;
import ch.epfl.dias.ops.BinaryOp;
import ch.epfl.dias.ops.volcano.*;
import ch.epfl.dias.store.DataType;
import ch.epfl.dias.store.row.RowStore;
import ch.epfl.dias.store.row.DBTuple;


public class NSMTuple {
	
	static RowStore orderStore;
	static RowStore lineItemStore;

	public static void run() throws IOException {
		System.out.println("NSMTuple");
		DataType[] orderSchema = new DataType[] { DataType.INT, DataType.INT, DataType.STRING, DataType.DOUBLE,
				DataType.STRING, DataType.STRING, DataType.STRING, DataType.INT, DataType.STRING };
		DataType[] lineitemSchema = new DataType[]{ DataType.INT, DataType.INT, DataType.INT, DataType.INT,
				DataType.DOUBLE, DataType.DOUBLE, DataType.DOUBLE, DataType.DOUBLE, DataType.STRING, DataType.STRING, DataType.STRING,
				DataType.STRING, DataType.STRING, DataType.STRING, DataType.STRING, DataType.STRING};
	
		orderStore = new RowStore(orderSchema, "input/orders_big.csv", "\\|");
	    orderStore.load();
	    lineItemStore = new RowStore(lineitemSchema, "input/lineitem_big.csv", "\\|");
	    lineItemStore.load();
	
	    long before = System.currentTimeMillis();
	    query1();
	    long now = System.currentTimeMillis();
	    System.out.println("-> Query1: " + (now-before) + " ms");

	    before = System.currentTimeMillis();
	    query2();
	    now = System.currentTimeMillis();
	    System.out.println("-> Query2: " + (now-before) + " ms");
	    
	    before = System.currentTimeMillis();
	    query3();
	    now = System.currentTimeMillis();
	    System.out.println("-> Query3: " + (now-before) + " ms");
	}
	
	public static void query1() {
		Scan scan = new Scan(orderStore);
	    Select sel = new Select(scan, BinaryOp.GT, 0, 400000);
	    int[] columnsToKeep = {0,1,2};
	    Project pro = new Project(sel, columnsToKeep);
	    ProjectAggregate agg = new ProjectAggregate(pro, Aggregate.COUNT, DataType.INT, 0);
	    agg.open();
	    DBTuple result = agg.next();
	    System.out.println("-> Query1 output: " + result.getFieldAsInt(0));
	  }
	
	public static void query2() {
		Scan scanOrder = new Scan(orderStore);
		Scan scanLineitem = new Scan(lineItemStore);
	
	    Select selOrder = new Select(scanOrder, BinaryOp.EQ, 0, 3);
	    Select selLineitem = new Select(scanLineitem, BinaryOp.EQ, 0, 3);
	
	    HashJoin join = new HashJoin(selOrder, selLineitem, 0, 0);
	    ProjectAggregate agg = new ProjectAggregate(join,Aggregate.COUNT, DataType.INT, 0);
	
	    agg.open();
	    DBTuple result = agg.next();
	    System.out.println("-> Query2 output: " + result.getFieldAsInt(0));
	}
	
	public static void query3() {
		Scan scanOrder = new Scan(orderStore);
	
	    Select selOrder = new Select(scanOrder, BinaryOp.GT, 0, 400000);
	    
	    int[] columnsToProject = {0,1,2};
	    Project pro = new Project(selOrder, columnsToProject);
	
	    ProjectAggregate agg = new ProjectAggregate(pro, Aggregate.COUNT, DataType.INT, 0);
	    
	    agg.open();
	    DBTuple result = agg.next();
	    System.out.println("-> Query3 output: " + result.getFieldAsInt(0));
	    agg.close();
	}

}
