package ch.epfl.dias.ops.volcano;

import java.io.File;

import ch.epfl.dias.ops.Aggregate;
import ch.epfl.dias.ops.BinaryOp;
import ch.epfl.dias.store.DataType;
import ch.epfl.dias.store.column.DBColumn;
import ch.epfl.dias.store.row.DBTuple;

public class Project implements VolcanoOperator {

	public VolcanoOperator child;
	public int[] fieldNo;

	public Project(VolcanoOperator child, int[] fieldNo) {
		this.child = child;
		this.fieldNo = fieldNo;
	}

	@Override
	public void open() {
		child.open();
	}

	@Override
	public DBTuple next() {
		DBTuple currentTuple = this.child.next();
		DataType[] types = new DataType[fieldNo.length];
		Object[] outTuple = new Object[fieldNo.length];
		if (!currentTuple.eof) {
			for (int i = 0; i < fieldNo.length; i++) {
				switch (currentTuple.getType(fieldNo[i])) {
					case INT:
						outTuple[i] = currentTuple.getFieldAsInt(fieldNo[i]);
						types[i] = currentTuple.getType(fieldNo[i]);
						break;
					case DOUBLE:
						outTuple[i] = currentTuple.getFieldAsDouble(fieldNo[i]);
						types[i] = currentTuple.getType(fieldNo[i]);
						break;
					case BOOLEAN:
						outTuple[i] = currentTuple.getFieldAsBoolean(fieldNo[i]);
						types[i] = currentTuple.getType(fieldNo[i]);
						break;
					case STRING:
						outTuple[i] = currentTuple.getFieldAsString(fieldNo[i]);
						types[i] = currentTuple.getType(fieldNo[i]);
						break;
					default:
						break;
				}
			}
			return new DBTuple(outTuple, types);
		} else
			return currentTuple;
	}

	@Override
	public void close() {
		child.close();
	}
}
