package ch.epfl.dias.tests;

import java.io.IOException;

import ch.epfl.dias.ops.Aggregate;
import ch.epfl.dias.ops.BinaryOp;
import ch.epfl.dias.ops.columnar.*;
import ch.epfl.dias.store.DataType;
import ch.epfl.dias.store.column.ColumnStore;
import ch.epfl.dias.store.column.DBColumn;


public class DSMLateMat {

	static ColumnStore orderStore;
	static ColumnStore lineItemStore;
	
	
	public static void run() throws IOException {
		System.out.println("DSMLateMat");
		DataType[] orderSchema = new DataType[] { DataType.INT, DataType.INT, DataType.STRING, DataType.DOUBLE,
				DataType.STRING, DataType.STRING, DataType.STRING, DataType.INT, DataType.STRING };
		DataType[] lineitemSchema = new DataType[]{ DataType.INT, DataType.INT, DataType.INT, DataType.INT,
				DataType.DOUBLE, DataType.DOUBLE, DataType.DOUBLE, DataType.DOUBLE, DataType.STRING, DataType.STRING, DataType.STRING,
				DataType.STRING, DataType.STRING, DataType.STRING, DataType.STRING, DataType.STRING};
	
		orderStore = new ColumnStore(orderSchema, "input/orders_big.csv", "\\|", true);
	    orderStore.load();
	    lineItemStore = new ColumnStore(lineitemSchema, "input/lineitem_big.csv", "\\|", true);
	    lineItemStore.load();
	
	    long before = System.currentTimeMillis();
	    query1();
	    long now = System.currentTimeMillis();
	    System.out.println("-> Query1: " + (now-before) + " ms");

	    before = System.currentTimeMillis();
	    query2();
	    now = System.currentTimeMillis();
	    System.out.println("-> Query2: " + (now-before) + " ms");
	    
	    before = System.currentTimeMillis();
	    query3();
	    now = System.currentTimeMillis();
	    System.out.println("-> Query3: " + (now-before) + " ms");
	   
	}
	
	public static void query1() {
	    Scan scan = new Scan(orderStore);
	    Select sel = new Select(scan, BinaryOp.GT, 0, 400000);
	    ProjectAggregate agg = new ProjectAggregate(sel, Aggregate.COUNT, DataType.INT, 0);
	    DBColumn[] result = agg.execute();
	    System.out.println("-> Query1 output: " + result[0].getAsInteger()[0]);
	  }
	
	public static void query2() {
		Scan scanOrder = new Scan(orderStore);
		Scan scanLineitem = new Scan(lineItemStore);
	
	    Select selOrder = new Select(scanOrder, BinaryOp.EQ, 0, 3);
	    Select selLineitem = new Select(scanLineitem, BinaryOp.EQ, 0, 3);
	
	    Join join = new Join(selOrder, selLineitem, 0, 0);
	    
	    ProjectAggregate agg = new ProjectAggregate(join, Aggregate.COUNT, DataType.INT, 0);
	
	    DBColumn[] result = agg.execute();
	    System.out.println("-> Query2 output: " + result[0].getAsInteger()[0]);
	}

	public static void query3() {
		Scan scanOrder = new Scan(orderStore);
	
	    Select selOrder = new Select(scanOrder, BinaryOp.GT, 0, 400000);
	    
	    int[] columnsToProject = {0,1,2};
	    Project pro = new Project(selOrder, columnsToProject);
	
	    ProjectAggregate agg = new ProjectAggregate(pro, Aggregate.COUNT, DataType.INT, 0);
	
	    DBColumn[] result = agg.execute();
	    System.out.println("-> Query3 output: " + result[0].getAsInteger()[0]);
	}
	
}
