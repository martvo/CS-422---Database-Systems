package ch.epfl.dias.ops.vector;

import ch.epfl.dias.ops.Aggregate;
import ch.epfl.dias.store.DataType;
import ch.epfl.dias.store.Store;
import ch.epfl.dias.store.column.DBColumn;
import ch.epfl.dias.store.row.DBTuple;

public class ProjectAggregate implements VectorOperator {

	public VectorOperator child;
	public Aggregate agg;
	public DataType dt;
	public int fieldNo;

	public ProjectAggregate(VectorOperator child, Aggregate agg, DataType dt, int fieldNo) {
		this.child = child;
		this.agg = agg;
		this.dt = dt;
		this.fieldNo = fieldNo;
	}

	@Override
	public void open() {
		child.open();
	}

	@Override
	public DBColumn[] next() {
		DBColumn[] childResult = child.next();
		if (childResult == null) {
			return null;
		}
		DBColumn[] outColumn = new DBColumn[1];
		Object[] result = aggregateColumn(childResult, agg, dt, fieldNo);
		return new DBColumn[] {new DBColumn(result, dt)};
	}
	
	public Object[] aggregateColumn(DBColumn[] childResult, Aggregate agg, DataType dt, int fieldNo) {
		Object[] result = null;
		
		switch (childResult[fieldNo].getType()) {
		case INT:
			result = intResult(childResult, agg, dt, fieldNo);
			break;
		case DOUBLE:
			result = doubleResult(childResult, agg, dt, fieldNo);
			break;
		case BOOLEAN:
			if (agg == Aggregate.COUNT) {
				result = count(childResult, fieldNo);
			}
			break;
		case STRING:
			if (agg == Aggregate.COUNT) {
				result = count(childResult, fieldNo);
			}
			break;
		default:
			return null;
		}
		return result;
	}
	
	public Object[] count(DBColumn[] childResult, int fieldNo) {
		int count = 0;
		while (childResult != null) {
			for (int i = 0; i < childResult[fieldNo].elements.length; i++) {
				count += 1;
			}
			childResult = child.next();
		}
		return new Object[] {count};
	}
	
	public Object[] intResult(DBColumn[] columns, Aggregate agg, DataType dt, int fieldNo) {
		int maxValue = Integer.MIN_VALUE;
		int minValue = Integer.MAX_VALUE;
		int countValue = 0;
		int sumValue = 0;
		
		while (columns != null) {
			for (Integer i : columns[fieldNo].getAsInteger()) {
				countValue += 1;
				sumValue += i;
				if (i < minValue) {
					minValue = i;
				}
				if (i > maxValue) {
					maxValue = i;
				}
			}
			columns = child.next();
		}
		switch (agg) {
		case COUNT:
			return new Object[] {countValue};
		case SUM:
			return new Object[] {sumValue};
		case MIN:
			return new Object[] {minValue};
		case MAX:
			return new Object[] {maxValue};
		case AVG:
			double avgValue = (double) sumValue / (double) countValue;
			return new Object[] {avgValue};
		default:
			break;
		}
		return null;
	}
	
	public Object[] doubleResult(DBColumn[] columns, Aggregate agg, DataType dt, int fieldNo) {
		double maxValue = Double.MIN_VALUE;
		double minValue = Double.MAX_VALUE;
		double countValue = 0.0;
		double sumValue = 0.0;
		
		while (columns != null) {
			for (Double i : columns[fieldNo].getAsDouble()) {
				countValue += 1;
				sumValue += i;
				if (i < minValue) {
					minValue = i;
				}
				if (i > maxValue) {
					maxValue = i;
				}
			}
			columns = child.next();
		}
		switch (agg) {
		case COUNT:
			return new Object[] {countValue};
		case SUM:
			return new Object[] {sumValue};
		case MIN:
			return new Object[] {minValue};
		case MAX:
			return new Object[] {maxValue};
		case AVG:
			double avgValue = (double) sumValue / (double) countValue;
			return new Object[] {avgValue};
		default:
			break;
		}
		return null;
	}

	@Override
	public void close() {
		child.close();
	}

}
