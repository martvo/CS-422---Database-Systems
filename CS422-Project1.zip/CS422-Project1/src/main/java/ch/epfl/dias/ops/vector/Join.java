package ch.epfl.dias.ops.vector;

import ch.epfl.dias.ops.BinaryOp;
import ch.epfl.dias.store.DataType;
import ch.epfl.dias.store.column.DBColumn;
import ch.epfl.dias.store.row.DBTuple;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;
import java.util.Queue;

public class Join implements VectorOperator {

	public VectorOperator leftChild;
	public VectorOperator rightChild;
	public int leftFieldNo;
	public int rightFieldNo;
	public HashMap<Object, List<DBTuple>> leftHashMap;
	public Iterator<DBTuple> hashedArrayIterator;
	public DBColumn[] rightChildResult;
	public Queue<DBTuple> resultQueue;
	public int maxTuples;

	public Join(VectorOperator leftChild, VectorOperator rightChild, int leftFieldNo, int rightFieldNo) {
		this.leftChild = leftChild;
		this.rightChild = rightChild;
		this.leftFieldNo = leftFieldNo;
		this.rightFieldNo = rightFieldNo;
		this.leftHashMap = new HashMap<Object, List<DBTuple>>();
		this.resultQueue = new LinkedList<DBTuple>();
	}

	@Override
	public void open() {
		leftChild.open();
		rightChild.open();
		fillLeftHashMap(leftChild, leftFieldNo);
		rightChildResult = rightChild.next();
		if (rightChildResult[0].elements.length > maxTuples) {
			maxTuples = rightChildResult[0].elements.length;
		}
	}
	
	public void fillLeftHashMap(VectorOperator leftChild, int leftFieldNo) {
		DBColumn[] leftResult = leftChild.next();
		if (leftResult == null) {
			return;
		}
		maxTuples = leftResult[0].elements.length;
		
		while (leftResult != null) {
			DBTuple[] leftTuples = colToTuple(leftResult);
			for (DBTuple tuple : leftTuples) {
				Object leftValue = tuple.fields[leftFieldNo];
				if (leftHashMap.get(leftValue) != null) {
					leftHashMap.get(leftValue).add(tuple);
				} else {
					leftHashMap.put(leftValue, new ArrayList<DBTuple>());
					leftHashMap.get(leftValue).add(tuple);
				}
			}
			leftResult = leftChild.next();
		}
	}
	
	public DBTuple[] colToTuple(DBColumn[] columns) {
		DBTuple[] outArray = new DBTuple[columns[0].elements.length];
		for (int i = 0; i < columns[0].elements.length; i++) {
			DataType[] types = new DataType[columns.length];
			Object[] fields = new Object[columns.length];
			
			for (int j = 0; j < columns.length; j++) {
				fields[j] = columns[j].elements[i];
				types[j] = columns[j].getType();
			}
			outArray[i] = new DBTuple(fields, types);
		}
		return outArray;
	}
	
	public DBColumn[] tuplesToCol(DBTuple[] tuples) {
		DBColumn[] result = new DBColumn[tuples[0].fields.length];
		for (int i = 0; i < tuples[0].fields.length; i++) {
			Object[] column = new Object[tuples.length];
			
			for (int j = 0; j < tuples.length; j++) {
				// System.out.println("field: " + i + ", tuple: " + j);
				column[j] = tuples[j].fields[i];
			}
			result[i] = new DBColumn(column, tuples[0].getType(i));
		}
		return result;
	}

	@Override
	public DBColumn[] next() {
		while (resultQueue.size() < maxTuples && rightChildResult != null) {
			DBTuple[] rightTupleToJoin = colToTuple(rightChildResult);
			for (int i = 0; i < rightChildResult[rightFieldNo].elements.length; i++) {
				setHashtableIterator(rightChildResult[rightFieldNo].elements[i]);
				while (hashedArrayIterator.hasNext()) {
					DBTuple leftTupleToJoin = hashedArrayIterator.next();
					DBTuple joinedTuple = joinTuples(leftTupleToJoin, rightTupleToJoin[i]);
					resultQueue.add(joinedTuple);
				}
			}
			// next vector before potential return 
			rightChildResult = rightChild.next();
			
			if (resultQueue.size() >= maxTuples) {
				DBTuple[] tuplesToReturn = getNTuples(maxTuples);
				return tuplesToCol(tuplesToReturn);
			}
		}
		if (resultQueue.size() >= maxTuples) {  // return N first tuples
			DBTuple[] tuplesToReturn = getNTuples(maxTuples);
			return tuplesToCol(tuplesToReturn);
		}
		if (resultQueue.size() > 0) {
			// return the remaining tuples
			DBTuple[] tuplesToReturn = getNTuples(resultQueue.size());
			return tuplesToCol(tuplesToReturn);
		}
		return null;
	}
	
	public DBTuple[] getNTuples(int numberOfTuples) {
		DBTuple[] result = new DBTuple[numberOfTuples];
		// System.out.println("Returning " + numberOfTuples + " tuples");
		for (int i = 0; i < numberOfTuples; i++) {
			result[i] = resultQueue.poll();
		}
		return result;
	}
	
	public void setHashtableIterator(Object rightValue) {
		if (leftHashMap.get(rightValue) != null) {
			hashedArrayIterator = leftHashMap.get(rightValue).iterator();
		} else {
			hashedArrayIterator = Collections.emptyIterator();
		}
	}
	
	public DBTuple joinTuples(DBTuple leftTuple, DBTuple righTuple) {
		DataType[] types = new DataType[leftTuple.types.length + righTuple.types.length];
		Object[] fields = new Object[leftTuple.fields.length + righTuple.types.length];
		
		for (int i = 0; i < leftTuple.fields.length; i++) {
			fields[i] = leftTuple.fields[i];
			types[i] = leftTuple.types[i];
		}
		
		int index = leftTuple.fields.length;
		for (int i = 0; i < righTuple.fields.length; i++) {
			fields[index] = righTuple.fields[i];
			types[index] = righTuple.types[i];
			index++;
		}
		return new DBTuple(fields, types);
	}

	@Override
	public void close() {
		rightChild.close();
		leftChild.close();
	}
}
