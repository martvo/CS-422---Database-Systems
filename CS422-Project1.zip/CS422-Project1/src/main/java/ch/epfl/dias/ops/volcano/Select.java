package ch.epfl.dias.ops.volcano;

import ch.epfl.dias.ops.BinaryOp;
import ch.epfl.dias.store.DataType;
import ch.epfl.dias.store.row.DBTuple;

public class Select implements VolcanoOperator {

	VolcanoOperator child;
	BinaryOp op;
	int fieldNo;
	int value;

	public Select(VolcanoOperator child, BinaryOp op, int fieldNo, int value) {
		this.child = child;
		this.op = op;
		this.fieldNo = fieldNo;
		this.value = value;
	}

	@Override
	public void open() {
		this.child.open();
	}

	@Override
	public DBTuple next() {
		DBTuple currentTuple = this.child.next();
		boolean satifiesQuery = false;
		
		while (!currentTuple.eof) {
			// try/catch???
			satifiesQuery = fitsQuery(currentTuple, op, fieldNo, value);
			
			// satifiesQuery = op.compareNumber(op, currentTuple.fields[fieldNo], value);
			if (satifiesQuery) {
				return currentTuple;
			}
			currentTuple = this.child.next();
		}
		return currentTuple;
	}
	
	public boolean fitsQuery(DBTuple currentTuple, BinaryOp op, int fieldNo, int value) {
		switch (currentTuple.getType(fieldNo)) {
		case INT:
			double valueV = (double) currentTuple.getFieldAsInt(fieldNo);
			return compare(op, value, valueV);
		case DOUBLE:
			double valueD = currentTuple.getFieldAsDouble(fieldNo);
			return compare(op, value, valueD);
		case BOOLEAN:
			return false;
		case STRING:
			return false;
		default:
			return false;
		}
	}
		
	public boolean compare(BinaryOp op, int value, double v) {
		switch (op) {
		case LT:
			if (v < value) {
				return true;
			}
			return false;
		case LE:
			if (v <= value) {
				return true;
			}
			return false;
		case EQ:
			if (v == value) {
				return true;
			}
			return false;
		case NE:
			if (v != value) {
				return true;
			}
			return false;
		case GT:
			if (v > value) {
				return true;
			}
			return false;
		case GE:
			if (v >= value) {
				return true;
			}
			return false;
		default:
			return false;
		}
	}

	@Override
	public void close() {
		this.child.close();
	}
}
