package ch.epfl.dias.store.PAX;

import java.util.ArrayList;
import java.util.List;

import ch.epfl.dias.store.DataType;
import ch.epfl.dias.store.column.DBColumn;
import ch.epfl.dias.store.row.DBTuple;

public class DBPAXpage {
	public List<DBColumn> page;
	public DataType[] types;

	public DBPAXpage(Object[][] page, DataType[] types) {
		this.page = new ArrayList<DBColumn>();
		this.types = types;
		
		for (int i = 0; i < page.length; i++) {
			this.page.add(new DBColumn(page[i], types[i]));
		}
		/*
		for (int x = 0; x < page.length; x++) {
			for (int y = 0; y < page[0].length; y++) {
				System.out.print(page[x][y] + " | ");
			}
			System.out.println();
		}
		*/
	}
	
	public DBTuple getTuple(int position) {
		if (position >= page.get(0).getLenght()) {
			return new DBTuple();
		}
		DataType[] tupleTypes = new DataType[page.size()];
		Object[] tuple = new Object[page.size()];
		for (int i = 0; i < page.size(); i++) {
			tupleTypes[i] = this.types[i]; 
			switch (tupleTypes[i]) {
				case INT:
					tuple[i] = this.page.get(i).getAsInteger()[position];
					break;
				case DOUBLE:
					tuple[i] = this.page.get(i).getAsDouble()[position];
					break;
				case BOOLEAN:
					tuple[i] = this.page.get(i).getAsBoolean()[position];
					break;
				case STRING:
					tuple[i] = this.page.get(i).getAsString()[position];
					break;
			}
		}
		return new DBTuple(tuple, types);
	}
	
	public DataType getType(int pos) {
		return types[pos];
	}
}
