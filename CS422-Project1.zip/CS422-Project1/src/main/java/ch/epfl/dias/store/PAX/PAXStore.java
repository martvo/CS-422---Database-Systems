package ch.epfl.dias.store.PAX;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import ch.epfl.dias.store.DataType;
import ch.epfl.dias.store.Store;
import ch.epfl.dias.store.column.DBColumn;
import ch.epfl.dias.store.row.DBTuple;

public class PAXStore extends Store {
	
	public List<DBPAXpage> PAXStore;
	public DataType[] schema;
	public String filename;
	public String delimiter;
	public int tuplesPerPage;

	public PAXStore(DataType[] schema, String filename, String delimiter, int tuplesPerPage) {
		this.schema = schema;
		this.filename = filename;
		this.delimiter = delimiter;
		this.tuplesPerPage = tuplesPerPage;
		this.PAXStore = new ArrayList<DBPAXpage>();
	}

	@Override
	public void load() throws IOException {
		//initialize Path object
		Path path = Paths.get(filename);
		
		List<String> strings = null;

		//create file

		// Path createdFilePath = Files.createFile(path);
		// System.out.println("File Created at Path : " + createdFilePath);
		
		strings = Files.readAllLines(path);
		// System.out.println("Read lines: \n" + strings);

		// Reason for two null values is that each paxpage uses tuplesPerPage
		Object[][] paxpage = new Object[schema.length][tuplesPerPage];
		if (tuplesPerPage == 0) {  // smart or not?
			PAXStore.add(new DBPAXpage(paxpage, this.schema));
		}
		int tuple_nr = 0;
		for (int i = 0; i < strings.size(); i++) {
			String[] parts = strings.get(i).split(this.delimiter);
			if (parts.length > schema.length) {
				throw new IOException("Count of columns doesn't match schema");
			}
			for (int j = 0; j < schema.length; j++) {
				Object element = parse_element(parts[j], this.schema[j]);
				paxpage[j][tuple_nr] = element;
			}
			tuple_nr++;
			if (tuple_nr >= tuplesPerPage) {
				PAXStore.add(new DBPAXpage(paxpage, this.schema));
				paxpage = new Object[schema.length][tuplesPerPage];
				tuple_nr = 0;
			}
		}
		// To add the last tuples if number of row is not divisible by tuplesPerPage
		if (tuple_nr != 0) {
			Object[][] last_paxpage = new Object[schema.length][strings.size() % tuplesPerPage];
			for (int i = 0; i < strings.size() % tuplesPerPage; i++) {
				for (int j = 0; j < paxpage.length; j++) {
					last_paxpage[j][i] = paxpage[j][i];
				}
			}
			PAXStore.add(new DBPAXpage(last_paxpage, schema));
		}
	}
	
	public Object parse_element(String element, DataType type) {
		Object out_element = null;
		switch (type) {
			case INT:
				out_element = Integer.parseInt(element);
				break;	
			case DOUBLE:
				out_element = Double.parseDouble(element);
				break;
			case BOOLEAN:
				out_element = Boolean.parseBoolean(element);
				break;	
			case STRING:
				out_element = element;
				break;
		}
		return out_element;
	}

	@Override
	public DBTuple getRow(int rownumber) {
		int pageNumber = rownumber / tuplesPerPage;
		int indexInPage = rownumber % tuplesPerPage;
		if (pageNumber >= PAXStore.size()) {
			return new DBTuple();
		}
		return PAXStore.get(pageNumber).getTuple(indexInPage);
	}
}
