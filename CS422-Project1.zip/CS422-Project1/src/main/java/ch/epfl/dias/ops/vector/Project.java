package ch.epfl.dias.ops.vector;

import ch.epfl.dias.ops.Aggregate;
import ch.epfl.dias.ops.BinaryOp;
import ch.epfl.dias.store.DataType;
import ch.epfl.dias.store.column.DBColumn;
import ch.epfl.dias.store.row.DBTuple;

public class Project implements VectorOperator {

	VectorOperator child;
	int[] fieldNo;

	public Project(VectorOperator child, int[] fieldNo) {
		this.child = child;
		this.fieldNo = fieldNo;
	}

	@Override
	public void open() {
		child.open();
	}

	@SuppressWarnings("unused")
	@Override
	public DBColumn[] next() {
		DBColumn[] childResult = child.next();
		DBColumn[] result = new DBColumn[fieldNo.length];
		if (childResult == null) {
			return null;
		} else {
			for (int i = 0; i < fieldNo.length; i++) {
				result[i] = childResult[fieldNo[i]];
			}
			return result;
		}
	}

	@Override
	public void close() {
		child.close();
	}
}
