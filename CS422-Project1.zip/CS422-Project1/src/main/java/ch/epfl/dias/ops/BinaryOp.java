package ch.epfl.dias.ops;

public enum BinaryOp {
    LT,LE,EQ,NE,GT,GE;
    
	// Not used now
	public boolean compareNumber(BinaryOp op, Integer tupleValue, Integer compareToValue) {
		if (tupleValue instanceof Number && compareToValue instanceof Number) {
			switch (op) {
			case LT:
				if ((double) tupleValue < (double) compareToValue) {
					return true;
				}
				return false;
			case LE:
				if ((double) tupleValue < (double) compareToValue) {
					return true;
				}
				return false;
			case EQ:
				if ((double) tupleValue < (double) compareToValue) {
					return true;
				}
				return false;
			case NE:
				if ((double) tupleValue < (double) compareToValue) {
					return true;
				}
				return false;
			case GT:
				if ((double) tupleValue < (double) compareToValue) {
					return true;
				}
				return false;
			case GE:
				if ((double) tupleValue < (double) compareToValue) {
					return true;
				}
				return false;
			default:
				return false;
			}
		}
		return false;
	}
}
