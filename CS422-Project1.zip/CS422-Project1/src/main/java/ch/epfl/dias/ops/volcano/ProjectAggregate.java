package ch.epfl.dias.ops.volcano;

import ch.epfl.dias.ops.Aggregate;
import ch.epfl.dias.store.DataType;
import ch.epfl.dias.store.Store;
import ch.epfl.dias.store.row.DBTuple;

public class ProjectAggregate implements VolcanoOperator {

	VolcanoOperator child;
	Aggregate agg;
	DataType dt;
	int fieldNo;

	public ProjectAggregate(VolcanoOperator child, Aggregate agg, DataType dt, int fieldNo) {
		this.child = child;
		this.agg = agg;
		this.dt = dt;
		this.fieldNo = fieldNo;
	}

	@Override
	public void open() {
		child.open();
	}

	@Override
	public DBTuple next() {
		DBTuple result = null;
		DBTuple currentTuple = child.next();
		switch (currentTuple.getType(fieldNo)) {
			case INT:
				result = intResult(currentTuple, agg, dt, fieldNo);
				break;
			case DOUBLE:
				result = doubleResult(currentTuple, agg, dt, fieldNo);
				break;
			case BOOLEAN:
				if (agg == Aggregate.COUNT) {
					result = count(currentTuple);
				} else {
					return new DBTuple();
				}
				break;
			case STRING:
				if (agg == Aggregate.COUNT) {
					result = count(currentTuple);
				} else {
					return new DBTuple();
				}
				break;
			default:
				return new DBTuple();
		}
		return result;
	}
	
	public DBTuple count(DBTuple currentTuple) {
		int result = 0;
		while (!currentTuple.eof) {
			result += 1;
			currentTuple = child.next();
		}
		return new DBTuple(new Object[] {result}, new DataType[] {DataType.INT});
	}
	
	public DBTuple intResult(DBTuple currentTuple, Aggregate agg, DataType dt, int fieldNo) {
		int maxValue = Integer.MIN_VALUE;
		int minValue = Integer.MAX_VALUE;
		int countValue = 0;
		int sumValue = 0;
		
		while(!currentTuple.eof) {
			countValue += 1;
			sumValue += currentTuple.getFieldAsInt(fieldNo);
			if (currentTuple.getFieldAsInt(fieldNo) < minValue) {
				minValue = currentTuple.getFieldAsInt(fieldNo);
			}
			if (currentTuple.getFieldAsInt(fieldNo) > minValue) {
				maxValue = currentTuple.getFieldAsInt(fieldNo);
			}
			currentTuple = child.next();
		}
		
		switch (agg) {
			case COUNT:
				return new DBTuple(new Object[] {countValue}, new DataType[] {DataType.INT});
			case SUM:
				return new DBTuple(new Object[] {sumValue}, new DataType[] {DataType.INT});
			case MIN:
				return new DBTuple(new Object[] {minValue}, new DataType[] {DataType.INT});
			case MAX:
				return new DBTuple(new Object[] {maxValue}, new DataType[] {DataType.INT});
			case AVG:
				double avgValue = (double) sumValue / (double) countValue;
				return new DBTuple(new Object[] {avgValue}, new DataType[] {DataType.DOUBLE});
			default:
				break;
		}
		return new DBTuple();
	}
	
	public DBTuple doubleResult(DBTuple currentTuple, Aggregate agg, DataType dt, int fieldNo) {
		double maxValue = Double.MIN_VALUE;
		double minValue = Double.MAX_VALUE;
		double countValue = 0.0;
		double sumValue = 0.0;
		
		while(!currentTuple.eof) {
			countValue += 1;
			sumValue += currentTuple.getFieldAsInt(fieldNo);
			if (currentTuple.getFieldAsInt(fieldNo) < minValue) {
				minValue = currentTuple.getFieldAsInt(fieldNo);
			}
			if (currentTuple.getFieldAsInt(fieldNo) > minValue) {
				maxValue = currentTuple.getFieldAsInt(fieldNo);
			}
			currentTuple = child.next();
		}
		
		switch (agg) {
			case COUNT:
				return new DBTuple(new Object[] {countValue}, new DataType[] {DataType.INT});
			case SUM:
				return new DBTuple(new Object[] {sumValue}, new DataType[] {DataType.DOUBLE});
			case MIN:
				return new DBTuple(new Object[] {minValue}, new DataType[] {DataType.DOUBLE});
			case MAX:
				return new DBTuple(new Object[] {maxValue}, new DataType[] {DataType.DOUBLE});
			case AVG:
				double avgValue = (double) sumValue / (double) countValue;
				return new DBTuple(new Object[] {avgValue}, new DataType[] {DataType.DOUBLE});
			default:
				break;
		}
		return new DBTuple();
	}

	@Override
	public void close() {
		child.close();
	}

}
