package ch.epfl.dias.ops.vector;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

import ch.epfl.dias.ops.BinaryOp;
import ch.epfl.dias.store.DataType;
import ch.epfl.dias.store.column.DBColumn;
import ch.epfl.dias.store.row.DBTuple;

public class Select implements VectorOperator {

	public VectorOperator child;
	public BinaryOp op;
	public int fieldNo;
	public int value;
	public Queue<DBTuple> resultQueue;
	public int maxTuples;
	public DBColumn[] childResult;

	public Select(VectorOperator child, BinaryOp op, int fieldNo, int value) {
		this.child = child;
		this.op = op;
		this.fieldNo = fieldNo;
		this.value = value;
		this.resultQueue = new LinkedList<DBTuple>();
	}
	
	@Override
	public void open() {
		child.open();
		childResult = child.next();
		maxTuples = childResult[0].getLenght();
	}

	@Override
	public DBColumn[] next() {
		while (resultQueue.size() < maxTuples && childResult != null) {
			List<Integer> filter = fitsQuery(childResult[fieldNo], op, value);
			
			DBColumn[] result = new DBColumn[childResult.length];
			
			for (int i = 0; i < childResult.length; i++) {
				DBColumn column = childResult[i];
				Object[] tempColumn = new Object[filter.size()];
				switch (column.getType()) {
					case INT:
						tempColumn = column.getAsInteger();
						break;
					case DOUBLE:
						tempColumn = column.getAsDouble();
						break;
					case BOOLEAN:
						tempColumn = column.getAsBoolean();
						break;
					case STRING:
						tempColumn = column.getAsString();
						break;
					default:
						tempColumn = null;
						break;
				}
				Object[] filteredColumn = new Object[filter.size()];
				for (int j = 0; j < filter.size(); j++) {
					filteredColumn[j] = tempColumn[filter.get(j)];
				}
				result[i] = new DBColumn(filteredColumn, childResult[i].getType());
			}
			
			DBTuple[] filteredTuples = colToTuple(result);
			for (DBTuple tuple : filteredTuples) {
				resultQueue.add(tuple);
			}
			
			// next vector before potential return 
			childResult = child.next();
			
			if (resultQueue.size() >= maxTuples) {
				DBTuple[] tuplesToReturn = getNTuples(maxTuples);
				return tuplesToCol(tuplesToReturn);
			}
		}
		if (resultQueue.size() >= maxTuples) {
			DBTuple[] tuplesToReturn = getNTuples(maxTuples);
			return tuplesToCol(tuplesToReturn);
		}
		if (resultQueue.size() > 0) {
			DBTuple[] tuplesToReturn = getNTuples(resultQueue.size());
			return tuplesToCol(tuplesToReturn);
		}
		return null;
	}
	
	public DBColumn[] next2() {
		if (childResult == null) {
			return null;
		}
		List<Integer> filter = fitsQuery(childResult[fieldNo], op, value);
		
		DBColumn[] result = new DBColumn[childResult.length];
		
		for (int i = 0; i < childResult.length; i++) {
			DBColumn column = childResult[i];
			Object[] tempColumn = new Object[filter.size()];
			switch (column.getType()) {
				case INT:
					tempColumn = column.getAsInteger();
					break;
				case DOUBLE:
					tempColumn = column.getAsDouble();
					break;
				case BOOLEAN:
					tempColumn = column.getAsBoolean();
					break;
				case STRING:
					tempColumn = column.getAsString();
					break;
				default:
					tempColumn = null;
					break;
			}
			Object[] filteredColumn = new Object[filter.size()];
			for (int j = 0; j < filter.size(); j++) {
				filteredColumn[j] = tempColumn[filter.get(j)];
			}
			result[i] = new DBColumn(filteredColumn, childResult[i].getType());
		}
		childResult = child.next();
		return result;
	}
	
	public List<Integer> fitsQuery(DBColumn column, BinaryOp op, int value) {
		switch (column.type) {
		case INT:
			return compare(column.getAsInteger(), op, value);
		case DOUBLE:
			//return compare(column.getAsInteger(), op, value);
			break;
		case BOOLEAN:
			break;
		case STRING:
			break;
		default:
			break;
		}
		return new ArrayList<Integer>();
	}
	
	public List<Integer> compare(Integer[] column, BinaryOp op, int value) {
		List<Integer> result = new ArrayList<Integer>();
		for (int i = 0; i < column.length; i++) {
			switch (op) {
			case LT:
				if (column[i] < value) {
					result.add(i);
				}
				break;
			case LE:
				if (column[i] <= value) {
					result.add(i);
				}		
				break;
			case EQ:
				if (column[i] == value) {
					result.add(i);
				}
				break;
			case NE:
				if (column[i] != value) {
					result.add(i);
				}
				break;
			case GT:
				if (column[i] > value) {
					result.add(i);
				}
				break;
			case GE:
				if (column[i] >= value) {
					result.add(i);
				}
				break;
			default:
				break;
			}
		}
		return result;
	}
	
	public DBTuple[] getNTuples(int numberOfTuples) {
		DBTuple[] result = new DBTuple[numberOfTuples];
		// System.out.println("Returning " + numberOfTuples + " tuples");
		for (int i = 0; i < numberOfTuples; i++) {
			result[i] = resultQueue.poll();
		}
		return result;
	}
	
	public DBColumn[] tuplesToCol(DBTuple[] tuples) {
		DBColumn[] result = new DBColumn[tuples[0].fields.length];
		for (int i = 0; i < tuples[0].fields.length; i++) {
			Object[] column = new Object[tuples.length];
			
			for (int j = 0; j < tuples.length; j++) {
				// System.out.println("field: " + i + ", tuple: " + j);
				column[j] = tuples[j].fields[i];
			}
			result[i] = new DBColumn(column, tuples[0].getType(i));
		}
		return result;
	}
	
	public DBTuple[] colToTuple(DBColumn[] columns) {
		DBTuple[] outArray = new DBTuple[columns[0].elements.length];
		for (int i = 0; i < columns[0].elements.length; i++) {
			DataType[] types = new DataType[columns.length];
			Object[] fields = new Object[columns.length];
			
			for (int j = 0; j < columns.length; j++) {
				fields[j] = columns[j].elements[i];
				types[j] = columns[j].getType();
			}
			outArray[i] = new DBTuple(fields, types);
		}
		return outArray;
	}

	@Override
	public void close() {
		child.close();
	}
}
