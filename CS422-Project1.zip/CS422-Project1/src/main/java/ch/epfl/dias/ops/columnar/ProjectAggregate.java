package ch.epfl.dias.ops.columnar;

import ch.epfl.dias.ops.Aggregate;
import ch.epfl.dias.store.DataType;
import ch.epfl.dias.store.column.DBColumn;

public class ProjectAggregate implements ColumnarOperator {

	ColumnarOperator child;
	Aggregate agg;
	DataType dt;
	int fieldNo;
	
	public ProjectAggregate(ColumnarOperator child, Aggregate agg, DataType dt, int fieldNo) {
		this.child = child;
		this.agg = agg;
		this.dt = dt;
		this.fieldNo = fieldNo;
		// System.out.println("Aggregate is: " + agg + ", on column " + fieldNo + " (" + dt + ")");
	}

	@Override
	public DBColumn[] execute() {
		DBColumn[] childResult = child.execute();
		DBColumn[] outColumns = new DBColumn[1];
		Object[] result = aggregateColumn(childResult[fieldNo], agg, dt, fieldNo);
		outColumns[0] = new DBColumn(result, dt);
		return outColumns;
	}
	
	public Object[] aggregateColumn(DBColumn childResult, Aggregate agg, DataType dt, int fieldNo) {
		Object[] result = new Object[1];
		
		switch (agg) {
			case COUNT:
				result[0] = count(childResult, dt, fieldNo);
				return result;
			case SUM:
				result[0] = sum(childResult, dt, fieldNo);
				return result;
			case MIN:
				result[0] = min(childResult, dt, fieldNo);
				return result;
			case MAX:
				result[0] = max(childResult, dt, fieldNo);
				return result;
			case AVG:
				result[0] = avg(childResult, dt, fieldNo);
				return result;
			default:
				return null;
		}
	}
	
	public Object count(DBColumn childResult, DataType dt, int fieldNo) {
		Integer result;
		switch (childResult.getType()) {
			case INT:
				result = childResult.getAsInteger().length;
				break;
			case DOUBLE:
				result = childResult.getAsDouble().length;
				break;		
			case BOOLEAN:
				result = childResult.getAsBoolean().length;
				break;
			case STRING:
				result = childResult.getAsString().length;
				break;
			default:
				return null;
			}
		return result;
	}
	
	public Object sum(DBColumn childResult, DataType dt, int fieldNo) {
		switch (childResult.getType()) {
		case INT:
			Integer sumInt = 0;
			for (Integer i : childResult.getAsInteger()) {
				sumInt += i;
			}
			return sumInt;
		case DOUBLE:
			Double sumDouble = 0.0;
			for (Double i : childResult.getAsDouble()) {
				sumDouble += i;
			}
			return sumDouble;
		default:
			return null;
		}
	}
	
	public Object min(DBColumn childResult, DataType dt, int fieldNo) {
		switch (childResult.getType()) {
		case INT:
			int minInteger = Integer.MAX_VALUE;
			for (Integer i : childResult.getAsInteger()) {
				if (i < minInteger) {
					minInteger = i;
				}
			}
			return minInteger;
		case DOUBLE:
			double minDouble = Double.MAX_VALUE;
			for (Double i : childResult.getAsDouble()) {
				if (i < minDouble) {
					minDouble = i;
				}
			}
			return minDouble;
		default:
			return null;
		}
	}
	
	public Object max(DBColumn childResult, DataType dt, int fieldNo) {
		switch (childResult.getType()) {
		case INT:
			int maxInteger = Integer.MIN_VALUE;
			for (Integer i : childResult.getAsInteger()) {
				if (i > maxInteger) {
					maxInteger = i;
				}
			}
			return maxInteger;
		case DOUBLE:
			double maxDouble = Double.MIN_VALUE;
			for (Double i : childResult.getAsDouble()) {
				if (i > maxDouble) {
					maxDouble = i;
				}
			}
			return maxDouble;
		default:
			return null;
		}
	}

	public Object avg(DBColumn childResult, DataType dt, int fieldNo) {
		int count = childResult.elements.length;
		if (count == 0) {
			return null;
		}
		switch (childResult.getType()) {
			case INT:
				int sumInt = 0;
				for (int i : childResult.getAsInteger()) {
					sumInt += i;
				}
				return (double) sumInt / (double) count;
			case DOUBLE:
				double sumDouble = 0.0;
				for (double i : childResult.getAsDouble()) {
					sumDouble += i;
				}
				return (double) sumDouble / (double) count;
			default:
				break;
		}
		return null;
	}
}
