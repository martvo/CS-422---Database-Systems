package ch.epfl.dias.ops.columnar;

import ch.epfl.dias.store.column.DBColumn;

public class Project implements ColumnarOperator {

	ColumnarOperator child;
	int[] columns;

	public Project(ColumnarOperator child, int[] columns) {
		this.child = child;
		this.columns = columns;
	}

	public DBColumn[] execute() {
		DBColumn[] childResult = child.execute();
		System.out.println("ChildResult lenght: " + childResult[0].elements.length);
		DBColumn[] outColumns;
		outColumns = new DBColumn[this.columns.length];
		for (int i = 0; i < this.columns.length; i++) {
			outColumns[i] = childResult[this.columns[i]];
		}
		return outColumns;
	}
}
