package ch.epfl.dias.ops.columnar;

import ch.epfl.dias.ops.BinaryOp;
import ch.epfl.dias.store.DataType;
import ch.epfl.dias.store.column.DBColumn;
import ch.epfl.dias.store.row.DBTuple;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

public class Join implements ColumnarOperator {

	public ColumnarOperator leftChild;
	public ColumnarOperator rightChild;
	public int leftFieldNo;
	public int rightFieldNo;
	public HashMap<Object, List<Integer>> leftDictionary;

	public Join(ColumnarOperator leftChild, ColumnarOperator rightChild, int leftFieldNo, int rightFieldNo) {
		this.leftChild = leftChild;
		this.rightChild = rightChild;
		this.leftFieldNo = leftFieldNo;
		this.rightFieldNo = rightFieldNo;
		this.leftDictionary = new HashMap<Object, List<Integer>>();
	}

	public DBColumn[] execute() {
		DBColumn[] leftChildResult = leftChild.execute();
		DBColumn[] rightChildResult = rightChild.execute();
		
		/*
		System.out.println("Left Child and Indices:");
		printChild(leftChildResult);
		printIndices(leftChildResult);
		System.out.println();
		System.out.println("Right Child and Indices");
		printChild(rightChildResult);
		printIndices(rightChildResult);
		System.out.println();
		*/
		
		// List<List<Integer>> indexPairs = new ArrayList<List<Integer>>();
		if (leftChildResult != null) {
			buildDictionary(leftChildResult[leftFieldNo]);
			List<List<Integer>> newIndicesTuples = fittingIndices(rightChildResult[rightFieldNo]);
			/*
			System.out.println("Fitting indices:");
			for (List<Integer> l : newIndicesTuples) {
				System.out.print(l.get(0) + ", " + l.get(1));
				System.out.println();
			}
			*/
			if (leftChildResult[leftFieldNo].lateMaterialization) {
				/*
				System.out.println("Left child indices:");
				for (Integer i : leftChildResult[0].getIndices()) {
					System.out.println(i);
				}
				System.out.println();
				System.out.println("Length left of indices and elements:");
				System.out.println(leftChildResult[0].indices.size());
				System.out.println(leftChildResult[0].elements.length);
				*/
				return lateMatJoin(leftChildResult, rightChildResult, newIndicesTuples);
			} else {
				return earlyMatJoin(leftChildResult, rightChildResult, newIndicesTuples);
			}
		}
		return null;
	}
	
	public void buildDictionary(DBColumn leftColumn) {
		Object[] leftValues;
		switch (leftColumn.getType()) {
		case INT:
			leftValues = leftColumn.getAsInteger();
			break;
		case DOUBLE:
			leftValues = leftColumn.getAsDouble();
			break;
		case BOOLEAN:
			leftValues = leftColumn.getAsBoolean();
			break;
		case STRING:
			leftValues = leftColumn.getAsString();
			break;
		default:
			leftValues = null;
			break;
		}
		/*
		System.out.println("leftValues lenght: " + leftValues.length);
		System.out.println("index length: " + leftColumn.getIndices().length);
		*/
		for (int i = 0; i < leftValues.length; i++) {
			if (leftDictionary.get(leftValues[i]) == null) {
				leftDictionary.put(leftValues[i], new ArrayList<Integer>());
				leftDictionary.get(leftValues[i]).add(leftColumn.getIndices()[i]);
			} else {
				leftDictionary.get(leftValues[i]).add(leftColumn.getIndices()[i]);
			}
		}
	}
	
	public List<List<Integer>> fittingIndices(DBColumn rightCol) {
		List<List<Integer>> outList = new ArrayList<List<Integer>>();
		Object[] rightValues;
		switch (rightCol.getType()) {
			case INT:
				rightValues = rightCol.getAsInteger();
				break;
			case DOUBLE:
				rightValues = rightCol.getAsDouble();
				break;
			case BOOLEAN:
				rightValues = rightCol.getAsBoolean();
				break;
			case STRING:
				rightValues = rightCol.getAsString();
				break;
			default:
				rightValues = null;
				break;
		}
		for (int j = 0; j < rightValues.length; j++) {
			List<Integer> leftIndices = leftDictionary.get(rightValues[j]);
			List<Integer> tuple = null;
			if (leftIndices != null) {
				for (Integer leftIndex : leftIndices) {
					tuple = new ArrayList<Integer>();
					tuple.add(leftIndex);
					tuple.add(rightCol.getIndices()[j]);
					outList.add(tuple);
				}
			}
		}
		return outList;
	}
	
	public DBColumn[] earlyMatJoin(DBColumn[] leftChildResult, DBColumn[] rightChildResult, List<List<Integer>> newIndicesTuples) {
		DBColumn[] joined = new DBColumn[leftChildResult.length + rightChildResult.length];
		for (int i = 0; i < leftChildResult.length; i++) {
			Object[] column = new Object[newIndicesTuples.size()];
			Object[] tmpColumn;
			switch (leftChildResult[i].getType()) {
			case INT:
				tmpColumn = leftChildResult[i].getAsInteger();
				break;
			case DOUBLE:
				tmpColumn = leftChildResult[i].getAsDouble();
				break;
			case BOOLEAN:
				tmpColumn = leftChildResult[i].getAsBoolean();
				break;
			case STRING:
				tmpColumn = leftChildResult[i].getAsString();
				break;
			default:
				tmpColumn = null;
				break;
			}
			for (int j = 0; j < newIndicesTuples.size(); j++) {
				column[j] = tmpColumn[newIndicesTuples.get(j).get(0)];
			}
			joined[i] = new DBColumn(column, leftChildResult[i].getType());
		}
		
		for (int i = 0; i < rightChildResult.length; i++) {
			Object[] column = new Object[newIndicesTuples.size()];
			Object[] tmpColumn;
			switch (rightChildResult[i].getType()) {
			case INT:
				tmpColumn = rightChildResult[i].getAsInteger();
				break;
			case DOUBLE:
				tmpColumn = rightChildResult[i].getAsDouble();
				break;
			case BOOLEAN:
				tmpColumn = rightChildResult[i].getAsBoolean();
				break;
			case STRING:
				tmpColumn = rightChildResult[i].getAsString();
				break;
			default:
				tmpColumn = null;
				break;
			}
			for (int j = 0; j < newIndicesTuples.size(); j++) {
				column[j] = tmpColumn[newIndicesTuples.get(j).get(1)];
			}
			joined[i + leftChildResult.length] = new DBColumn(column, rightChildResult[i].getType());
		}
		return joined;
	}
	
	public DBColumn[] lateMatJoin(DBColumn[] leftChildResult, DBColumn[] rightChildResult, List<List<Integer>> newIndicesTuples) {
		DBColumn[] joinedColumns = new DBColumn[leftChildResult.length + rightChildResult.length];
		int[] tableSplits;
		for (int i = 0; i < leftChildResult.length; i++) {
			leftChildResult[i].setIndices(newIndicesTuples);
			joinedColumns[i] = leftChildResult[i];
		}
		for (int j = 0; j < rightChildResult.length; j++) {
			rightChildResult[j].setIndices(newIndicesTuples);
			rightChildResult[j].setBelongsToTable(1);
			joinedColumns[j + leftChildResult.length] = rightChildResult[j];
		}
		
		return joinedColumns;
	}
	
	public void printChild(DBColumn[] columns) {
		for (int j = 0; j < columns[0].getAsInteger().length; j++) {
			for (int i = 0; i < columns.length; i++) {
				switch (columns[i].getType()) {
				case INT:
					System.out.print(columns[i].getAsInteger()[j] + " | ");
					break;
				case DOUBLE:
					System.out.print(columns[i].getAsDouble()[j] + " | ");
					break;
				case BOOLEAN:
					System.out.print(columns[i].getAsBoolean()[j] + " | ");
					break;
				case STRING:
					System.out.print(columns[i].getAsString()[j] + " | ");
					break;
				}
			}
			System.out.println();
		}
	}
	
	public void printIndices(DBColumn[] columns) {
		for (Integer i : columns[0].getIndices()) {
			System.out.print(i + " | ");
		}
		System.out.println();
	}
}
