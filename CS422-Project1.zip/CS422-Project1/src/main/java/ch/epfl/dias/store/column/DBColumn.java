package ch.epfl.dias.store.column;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import ch.epfl.dias.store.DataType;

public class DBColumn {
	public Object[] elements;
	public DataType type;
	// public Integer[] indices;
	public boolean lateMaterialization;
	public List<List<Integer>> indices;
	public int belongsToTable;
	// public int[] tableSplits;
	
	
	public DBColumn(Object[] elements, DataType type) {
		this.elements = elements;
		this.type = type;
		this.indices = new ArrayList<List<Integer>>();
		resetIndices();
		/*
		List<Integer> indexes;
		for (int i = 0; i < elements.length; i++) {
			indexes = new ArrayList<Integer>();
			indexes.add(i);
			indices.add(indexes);
		}
		belongsToTable = 0;
		*/
		
		/*
		indices = new Integer[elements.length];
		for (int i = 0; i < elements.length; i++) {
			indices[i] = i;
		}
		*/
	}
	
	public void resetIndices() {
		indices = new ArrayList<List<Integer>>();
		List<Integer> indexes;
		for (int i = 0; i < elements.length; i++) {
			indexes = new ArrayList<Integer>();
			indexes.add(i);
			indices.add(indexes);
		}
		belongsToTable = 0;
	}
	
	public void setBelongsToTable(int i) {
		this.belongsToTable = i;
	}
	
	public void setLateMaterialization() {
		this.lateMaterialization = true;
	}
	
	public Integer[] getAsInteger() {
		if (lateMaterialization) {
			Integer[] out = new Integer[indices.size()];
			for (int i = 0; i < indices.size(); i++) {
				out[i] = (Integer) elements[indices.get(i).get(belongsToTable)];
			}
			return out;
		}
		Integer outList[] = Arrays.asList(elements).toArray(new Integer[elements.length]);
		return outList;
	}

	public Double[] getAsDouble() {
		if (lateMaterialization) {
			Double[] out = new Double[indices.size()];
			for (int i = 0; i < indices.size(); i++) {
				out[i] = (Double) elements[indices.get(i).get(belongsToTable)];
			}
			return out;
		}
		Double outList[] = Arrays.asList(elements).toArray(new Double[elements.length]);
		return outList;
	}

	public Boolean[] getAsBoolean() {
		if (lateMaterialization) {
			Boolean[] out = new Boolean[indices.size()];
			for (int i = 0; i < indices.size(); i++) {
				out[i] = (Boolean) elements[indices.get(i).get(belongsToTable)];
			}
			return out;
		}
		Boolean outList[] = Arrays.asList(elements).toArray(new Boolean[elements.length]);
		return outList;
	}

	public String[] getAsString() {
		if (lateMaterialization) {
			String[] out = new String[indices.size()];
			for (int i = 0; i < indices.size(); i++) {
				out[i] = (String) elements[indices.get(i).get(belongsToTable)];
			}
			return out;
		}
		String outList[] = Arrays.asList(elements).toArray(new String[elements.length]);
		return outList;
	}
	
	public DataType getType() {
		return this.type;
	}
	
	public int getLenght() {
		return elements.length;
	}
	
	public void filterIndices2(List<List<Integer>> newIndices) {
		List<List<Integer>> tmpIndices = new ArrayList<List<Integer>>();
		for (int i = 0; i < newIndices.size(); i++) {
			tmpIndices.add(newIndices.get(i));
		}
		indices = tmpIndices;
	}
	
	public void filterIndices(Integer[] newIndices) {
		List<List<Integer>> tmpIndices = new ArrayList<List<Integer>>();
		for (int i = 0; i < newIndices.length; i++) {
			tmpIndices.add(indices.get(newIndices[i]));
		}
		indices = tmpIndices;
	}
	
	public void setIndices(List<List<Integer>> newIndices) {
		this.indices = newIndices;
	}
	
	public Integer[] getIndices() {
		Integer[] index = new Integer[indices.size()];
		for (int i = 0; i < indices.size(); i++) {
			index[i] = indices.get(i).get(belongsToTable);
		}
		return index;
	}
	
	/*
	public void setTableSplits(int[] splits) {
		this.tableSplits = splits;
	}
	 */
}
