package ch.epfl.dias.store.row;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import ch.epfl.dias.store.DataType;
import ch.epfl.dias.store.Store;
import ch.epfl.dias.store.row.DBTuple;

public class RowStore extends Store {

	public List<DBTuple> rowStore;
	public DataType[] schema;
	public String filename;
	public String delimiter;

	public RowStore(DataType[] schema, String filename, String delimiter) {
		rowStore = new ArrayList<DBTuple>();
		this.schema = schema;
		this.filename = filename;
		this.delimiter = delimiter;
	}

	@Override
	public void load() throws IOException {
		//initialize Path object
		Path path = Paths.get(filename);

		//create file
		// Path createdFilePath = Files.createFile(path);
		// System.out.println("File Created at Path : " + createdFilePath);
		
		List<String> strings = Files.readAllLines(path);
		// System.out.println("Read lines: \n" + strings);
		
		for (String string : strings) {
			String[] parts = string.split(delimiter);
			if (parts.length > schema.length) {
				throw new IOException("Count of columns doesn't match schema");
			}
			Object[] newParts = parse_line(Arrays.copyOfRange(parts, 0, schema.length), this.schema);
			rowStore.add(new DBTuple(newParts, this.schema));
		}
		
	}
	
	public Object[] parse_line(String[] parts, DataType[] schema) {
		Object[] outList = new Object[schema.length];
		for (int i = 0; i < outList.length; i++) {
			switch (schema[i]) {
				case INT:
					outList[i] = Integer.parseInt(parts[i]);
					break;	
				case DOUBLE:
					outList[i] = Double.parseDouble(parts[i]);
					break;
				case BOOLEAN:
					outList[i] = Boolean.parseBoolean(parts[i]);
					break;	
				case STRING:
					outList[i] = parts[i];
					break;
			}
		}
		return outList;
	}

	@Override
	public DBTuple getRow(int rownumber) {
		if (rownumber >= rowStore.size()) {
			return new DBTuple();
		}
		DBTuple outTuple = this.rowStore.get(rownumber);
		return outTuple;
	}
}
