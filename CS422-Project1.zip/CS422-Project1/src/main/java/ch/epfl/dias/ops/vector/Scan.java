package ch.epfl.dias.ops.vector;

import java.util.ArrayList;
import java.util.List;

import ch.epfl.dias.store.DataType;
import ch.epfl.dias.store.Store;
import ch.epfl.dias.store.column.DBColumn;

public class Scan implements VectorOperator {

	Store store;
	int vectorsize;
	int currentPageIndex;
	int numberOfFields;
	boolean endOfFile;

	public Scan(Store store, int vectorsize) {
		this.store = store;
		this.vectorsize = vectorsize;
	}
	
	@Override
	public void open() {
		currentPageIndex = 0;
		// DBColumn[] allColumns = store.getColumns(new int[] {});
		// numberOfFields = allColumns.length;
		endOfFile = false;
	}
	
	@Override
	public DBColumn[] next() {
		if (endOfFile) {
			return null;
		}
		List<DBColumn> result = new ArrayList<DBColumn>();
		int index = 0;
		DBColumn[] current = store.getColumns(new int[] {index});
		while (current != null) {
			DBColumn column = current[0];
			Object[] currentColumn = column.elements;
			List<Object> columnSubset = new ArrayList<Object>();
			for (int j = currentPageIndex; j < currentPageIndex + vectorsize; j++) {
				if (j >= currentColumn.length) {
					endOfFile = true;
				} else {
					columnSubset.add(currentColumn[j]);
				}
			}
			result.add(new DBColumn(columnSubset.toArray(new Object[columnSubset.size()]), column.type));
			index++;
			current = store.getColumns(new int[] {index});
		}
		currentPageIndex += vectorsize;
		DBColumn[] outArray = new DBColumn[result.size()];
		for (int i = 0; i < result.size(); i++) {
			outArray[i] = result.get(i);
		}
		return outArray;
	}

	public DBColumn[] next2() {
		if (endOfFile) {
			return null;
		}
		System.out.println("Next");
		List<DBColumn> result = new ArrayList<DBColumn>();
		for (int i = 0; i < numberOfFields; i++) {
			DBColumn current = store.getColumns(new int[] {i})[0];
			System.out.println(i);
			Object[] currentColumn = current.elements;
			List<Object> columnSubset = new ArrayList<Object>();
			for (int j = currentPageIndex; j < currentPageIndex + vectorsize; j++) {
				if (j >= currentColumn.length) {
					endOfFile = true;
				} else {
					columnSubset.add(currentColumn[j]);
				}
			}
			result.add(new DBColumn(columnSubset.toArray(new Object[columnSubset.size()]), current.type));
		}
		currentPageIndex += vectorsize;
		DBColumn[] outArray = new DBColumn[result.size()];
		for (int i = 0; i < result.size(); i++) {
			outArray[i] = result.get(i);
		}
		return outArray;
	}

	@Override
	public void close() {
		currentPageIndex = 0;
		store = null;
	}
}
