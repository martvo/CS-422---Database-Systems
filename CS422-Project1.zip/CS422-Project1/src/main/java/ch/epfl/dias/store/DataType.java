package ch.epfl.dias.store;

public enum DataType {
    INT, DOUBLE, BOOLEAN, STRING
}
