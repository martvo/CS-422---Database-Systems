CS422 - Project2
-----------------

To load the project in Scala-IDE for Eclipse execute: 
> sbt eclipse

and then inside Eclipse import the project:
File -> Import -> Existing Projects into Workspace

In the case of compilation issues make sure to set the Scala version (right click on the project -> Scala -> Set the Scala installation) to a compatible version with that of build.sbt

To compile through the command line execute:
> sbt package




