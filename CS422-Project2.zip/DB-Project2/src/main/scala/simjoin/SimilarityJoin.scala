package simjoin

import org.apache.spark.rdd.RDD
import org.slf4j.LoggerFactory

import scala.Array._

class SimilarityJoin(numAnchors: Int, distThreshold:Int) extends java.io.Serializable {
  val logger = LoggerFactory.getLogger("SimilarityJoin")
  var rdd: RDD[String] = null

  /*
   * this method gets as input a dataset and the index of an attribute
   * of the dataset, and returns the result of the similarity self join on
   * that attribute.
   * */

  val r = scala.util.Random

  // Levenshtein distance function from https://rosettacode.org/wiki/Levenshtein_distance#Scala
  def distance(s1: String, s2: String): Int = {
    val dist = Array.tabulate(s2.length + 1, s1.length + 1) { (j, i) => if (j == 0) i else if (i == 0) j else 0 }

    @inline
    def minimum(i: Int*): Int = i.min

    for {j <- dist.indices.tail
         i <- dist(0).indices.tail} dist(j)(i) =
      if (s2(j - 1) == s1(i - 1)) dist(j - 1)(i - 1)
      else minimum(dist(j - 1)(i) + 1, dist(j)(i - 1) + 1, dist(j - 1)(i - 1) + 1)

    dist(s2.length)(s1.length)
  }

  def similarity_join(dataset: Dataset, attrIndex: Int) : RDD[(String, String)] = {

    val rdd = dataset.getRDD()
    val schema = dataset.getSchema()
    val index = schema.indexOf(attrIndex)

    val anchorProb = numAnchors.toDouble / rdd.count()

    // Get anchors based on the anchor probability (Or the number of wanted anchors)
    val anchors = rdd.takeSample(withReplacement=false, num=numAnchors, seed=r.nextInt())
    println("Actual number of Anchors: " + anchors.length)

    /*
    If we don't need to use the randomness.
    val anchors = rdd.takeSample(withReplacement=false, num=numAnchors, seed=r.nextInt())
    If we want a more "random" number of anchor use this
    val anchors = rdd.sample(withReplacement=false, fraction=anchorProb, seed=r.nextInt()).collect()
     */

    val anchorMap = anchors.zipWithIndex.map{case (k,v) => (k(0), v+1)}.toMap
    // println(anchorMap)

    // Creates a RDD with anchor, query string, distance between them and true if it is in the
    // home partition for the anchor
    val partition_rdd = rdd.flatMap(q => {
      // Calculate the distance from query string to each anchor
      val anchor_dist = anchors.map(a => {
        (a(0).toString, q(0).toString, distance(q(0).toString, a(0).toString))
      })

      // Sort the array based on the length from the query
      val sorted_dist = anchor_dist.sortBy(_._3)

      // Get the closest anchor and its distance
      val home_anchor = sorted_dist(0)
      val home_anchor_dist = home_anchor._3
      var partition = Array((home_anchor._1, (home_anchor._2, home_anchor._3, true)))

      // Find which anchors have the query string in its outer partition
      var break_out = false
      var counter = 1
      while (!break_out && counter < sorted_dist.length) {
        val current_tuple = sorted_dist(counter)

        // Add to the array if distance is satisfied and the id of the current_tuple is larger than
        // the id of the home anchor (as stated in part 7.2 in the paper
        // If not satisfied: break. Non of the other anchors will satisfy the inequality either
        if ((current_tuple._3 <= home_anchor_dist + 2 * distThreshold) && (anchorMap(home_anchor._1) < anchorMap(current_tuple._1))) {
          partition = concat(partition, Array((current_tuple._1, (current_tuple._2, current_tuple._3, false))))
        } else {
          break_out = true
        }
        counter = counter + 1
      }

      partition
    })

    // To see the bloat
    // println(partition_rdd.countByKey())

    // Tuple on the form (K, (V, V))
    val joined = partition_rdd.join(partition_rdd).filter(tuple => {
      // Keep the row if the two entries both are not in outer partition and distance between them is less or equal to
      // the distance threshold and they are not the same string
      (tuple._2._1._3 || tuple._2._2._3) && (distance(tuple._2._1._1, tuple._2._2._1) <= distThreshold) && (tuple._2._1._1 != tuple._2._2._1)
    }).map(tuple => {
      // Map the tuple to only contain the strings of the two entries
      (tuple._2._1._1, tuple._2._2._1)
    })

    joined
  }
}
