package cubeoperator

import com.sun.xml.internal.bind.v2.schemagen.xmlschema.List

//Spark
import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.sql.functions.udf
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.Row

class CubeOperator(reducers: Int) extends Serializable {

  /*
 * This method gets as input one dataset, the grouping attributes of the cube (CUBE BY clause)
 * the attribute on which the aggregation is performed
 * and the aggregate function (it has to be one of "COUNT", "SUM", "MIN", "MAX", "AVG")
 * and returns an RDD with the result in the form of <key = string, value = double> pairs.
 * The key is used to uniquely identify a group that corresponds to a certain combination of attribute values.
 * You are free to do that following your own naming convention.
 * The value is the aggregation result.
 * You are not allowed to change the definition of this function or the names of the aggregate functions.
 * */

  val getOperator = (aggOp: String) => {
    aggOp match {
      case "MIN" => (d1:Double, d2:Double) => if (d1 < d2) d1 else d2
      case "MAX" => (d1:Double, d2:Double) => if (d1 > d2) d1 else d2
      case _ => (d1:Double, d2:Double) => d1 + d2
    }
  }


  val getKeyFromRow = (row: Row, fields: Seq[String]) => {
    val cubeFields = fields.map(field => {
      row.getAs(field).toString()
    })
    cubeFields.reduce(_ + "-" + _)
  }

  val subsets = (s: String) => {
    val spl = s.split("-")
    val n = spl.length
    val indexes = 0 to n -1
    var retList = Seq[String]()
    val subsets = indexes.toSet.subsets()
    subsets.foreach(set => {
      val tempArr = spl.clone()
      set.foreach(index => {
        tempArr(index) = "*"
      })
      retList :+= tempArr.mkString("-")
    })
    retList
  }

  val simpleCombiner =  (d:Double) =>  d
  val avgCombiner = (t: (Double, Double)) => t

  val subsetKeySimple = (key: String, value: Double) => {
    val subkeys = subsets(key)
    subkeys.map(k => {
      (k, value)
    })
  }
  val getCombiner = (aggOp: String) => {
    aggOp match {
      case "MIN" => (d1: Double, d2: Double) => if (d1 > d2) d2 else d1
      case "MAX" => (d1: Double, d2: Double) => if (d1 > d2) d1 else d1
      case _ => (d1: Double, d2: Double) => d1 + d2
    }
  }

  val combinerAvg = (t1: (Double, Double), t2: (Double, Double)) => {
    (t1._1 + t2._1, t1._2 + t2._2)
  }

  val subsetKeyVal = (key: String, value: (Double, Double)) => {
    val subkeys = subsets(key)
    subkeys.map(k => {
      (k, value)
    })
  }


  val anyToDouble = (v: Any) => {
    v match {
      case i: Int => Some(i.toDouble)
      case l: Long => Some(l.toDouble)
      case d: Double => Some(d)
      case _ => None
    }
  }

  def cube(dataset: Dataset, groupingAttributes: Seq[String], aggAttribute: String, agg: String): RDD[(String, Double)] = {
    val rdd = dataset.getRDD()
    if (agg == "AVG") {
      val mappedData = rdd.map(row => {
        val cubeVal = anyToDouble(row.getAs(aggAttribute)).getOrElse(0.0)
        (getKeyFromRow(row, groupingAttributes), (cubeVal, 1.0))
      })
      val combined = mappedData.combineByKey(avgCombiner, combinerAvg, combinerAvg)
      val reduced = combined.reduceByKey((x, y) => (x._1 + y._1, x._2 + y._2))
      val flattened = reduced.flatMap(tup => subsetKeyVal(tup._1, tup._2))
      val reducedFlattened = flattened.reduceByKey((x, y) => (x._1 + y._1, x._2 + y._2))
      //Calculating the partial averages
      reducedFlattened.map(row => {
        val countAndSumTuple = row._2
        (row._1, if (countAndSumTuple._2 == 0)  0.0 else countAndSumTuple._1 / countAndSumTuple._2)
      })
    }
    else {
      val mappedData = rdd.map(row => {
        val key = getKeyFromRow(row, groupingAttributes)
        val cubeVal = anyToDouble(row.getAs(aggAttribute)).getOrElse(0.0)
        (getKeyFromRow(row, groupingAttributes), cubeVal)
      })
      val merger = getCombiner(agg)
      val combined1 = mappedData.combineByKey(simpleCombiner, merger, merger)
      val reduce = getOperator(agg)
      val reduced = combined1.reduceByKey(reduce)
      val flattened = reduced.flatMap(tup => subsetKeySimple(tup._1, tup._2))
      //val combined = flattened.combineByKey(simpleCombiner, merger, merger)
      flattened.reduceByKey(reduce)
    }

  }



  def cube_naive(dataset: Dataset, groupingAttributes: Seq[String], aggAttribute: String, agg: String): RDD[(String, Double)] = {

    val rdd = dataset.getRDD()
    if (agg == "AVG") {
      val mappedData = rdd.map(row => {
        val cubeVal = anyToDouble(row.getAs(aggAttribute)).getOrElse(0.0)
        (getKeyFromRow(row, groupingAttributes), (cubeVal, 1.0))
      })
      val combined = mappedData.combineByKey(avgCombiner, combinerAvg, combinerAvg)
      val reduced = combined.reduceByKey((x, y) => (x._1 + y._1, x._2 + y._2))
      val flattened = reduced.flatMap(tup => subsetKeyVal(tup._1, tup._2))
      val reducedFlattened = flattened.reduceByKey((x, y) => (x._1 + y._1, x._2 + y._2))
      //Calculating the partial averages
      reducedFlattened.map(row => {
        val countAndSumTuple = row._2
        (row._1, if (countAndSumTuple._2 == 0)  0.0 else countAndSumTuple._1 / countAndSumTuple._2)
      })
    }
    else {
      val mappedData = rdd.map(row => {
        val key = getKeyFromRow(row, groupingAttributes)
        val cubeVal = anyToDouble(row.getAs(aggAttribute)).getOrElse(0.0)
        (getKeyFromRow(row, groupingAttributes), cubeVal)
      })
      val flattened = mappedData.flatMap(tup => subsetKeySimple(tup._1, tup._2))
      val reduce = getOperator(agg)
      val reduced = flattened.reduceByKey(reduce)
      //val combined = flattened.combineByKey(simpleCombiner, merger, merger)
      reduced.reduceByKey(reduce)
    }
  }

}
