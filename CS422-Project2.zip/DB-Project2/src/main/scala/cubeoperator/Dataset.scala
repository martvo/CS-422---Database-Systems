package cubeoperator

import org.apache.spark.rdd.RDD
import org.apache.spark.sql.Row

class Dataset(rdd: RDD[Row], schema: List[String]) {
  val this.rdd = rdd
  val this.schema = schema
  
  def getRDD(): RDD[Row] = {
    rdd
  }

  def getFieldIndex(field: String):Int = {
    this.schema.indexOf(field)
  }

  def getFieldIndexes(fields: List[String]):List[Int] = {
    val indexes = fields.map(field => {
      this.getFieldIndex(field)
    })
    indexes
  }
  
  def getSchema(): List[String] = {
    schema
  }
}