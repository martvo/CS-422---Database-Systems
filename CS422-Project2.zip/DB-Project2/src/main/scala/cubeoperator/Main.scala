package cubeoperator

import org.apache.spark.{SparkConf, SparkContext}

import org.apache.spark.sql.types._
import org.apache.spark.sql.expressions._
import org.apache.spark.sql.functions._
import java.io._

object Main {
  def main(args: Array[String]) {
    val reducers = 20
    val inputfile_hdfs = "/user/cs422-group42/part1/lineorder_small.tbl"

    val inputFile= "../lineorder_small.tbl"
    //val input = new File(getClass.getResource(inputFile).getFile).getPath

    val sparkConf = new SparkConf().setAppName("CS422-Project2")//.setMaster("local[16]")
    val ctx = new SparkContext(sparkConf)
    val sqlContext = new org.apache.spark.sql.SQLContext(ctx)

    val df = sqlContext.read
      .format("com.databricks.spark.csv")
      .option("header", "true")
      .option("inferSchema", "true")
      .option("delimiter", "|")
      .load(inputfile_hdfs)

    val rdd = df.rdd
    val schema = df.schema.toList.map(x => x.name)

    val dataset = new Dataset(rdd, schema)

    val cb = new CubeOperator(reducers)

    var groupingList = List("lo_suppkey")
    val t1 = System.nanoTime

    val res = cb.cube(  dataset, groupingList, "lo_supplycost", "SUM")

    val duration = (System.nanoTime - t1) / 1e9d
    System.out.println("Operation of cube OPT took: ", duration, " seconds")

    /*
       The above call corresponds to the query:
       SELECT lo_suppkey, lo_shipmode, lo_orderdate, SUM (lo_supplycost)
       FROM LINEORDER
       CUBE BY lo_suppkey, lo_shipmode, lo_orderdate
     */


    //Perform the same query using SparkSQL
    /*val q1 = df.cube("lo_suppkey","lo_shipmode","lo_orderdate")
      .agg(sum("lo_supplycost") as "sum supplycost")
    q1.show
    assert(q1.count() == res.count())*/


  }
}