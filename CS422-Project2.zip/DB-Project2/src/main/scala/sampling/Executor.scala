package sampling

import com.sun.org.apache.xalan.internal.xsltc.compiler.util.StringType
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, SparkSession, Row}
import org.apache.spark.sql.types._

object Executor {
  def getSchema(lineitem: DataFrame):StructType = {
    //TODO:Make this functions do something
    val old_schema = lineitem.schema
    val new_field = StructField("ratio", DoubleType, true)
    old_schema.add(new_field)
  }

  def setGlobalView(desc: Description, lineitem: DataFrame, session: SparkSession, query: String) = {
    val customer: DataFrame = desc.customer
    val orders  : DataFrame = desc.orders
    val supplier: DataFrame = desc.supplier
    val nation  : DataFrame = desc.nation
    val region  : DataFrame = desc.region
    val part = desc.part
    val partsupp = desc.partsupp
    lineitem.createGlobalTempView("lineitem")
    customer.createGlobalTempView("customer")
    orders.createGlobalTempView("orders")
    supplier.createGlobalTempView("supplier")
    nation.createGlobalTempView("nation")
    region.createGlobalTempView("region")
    part.createGlobalTempView("part")
    partsupp.createGlobalTempView("partsupp")

    session.sql(query).rdd
  }
  def execute_Q1(desc: Description, session: SparkSession, params: List[Any]) = {
    // TODO: implement
    val queryNum = 1
    assert(params.size == 1)
    var lineitem = desc.lineitem
    val queryMap = desc.sampleDescription.asInstanceOf[Map[Int, Int]]
    //This is used to compensate when a sample is being used
    var compensate = ""
    if (queryMap != null && queryMap.contains(queryNum)) {
      val new_schema = getSchema(desc.lineitem)
      val sample_index = queryMap(queryNum)
      val rdd = desc.samples(sample_index).asInstanceOf[RDD[Row]]
      val new_lineitem = session.createDataFrame(rdd, new_schema)
      lineitem = new_lineitem
      compensate = " * ratio"
    }
    val q1 = s"""select
                	l_returnflag,
                	l_linestatus,
                	sum(l_quantity ${compensate}) as sum_qty,
                	sum(l_extendedprice ${compensate}) as sum_base_price,
                	sum(l_extendedprice * (1 - l_discount) ${compensate}) as sum_disc_price,
                	sum(l_extendedprice * (1 - l_discount) ${compensate} * (1 + l_tax)) as sum_charge,
                	avg(l_quantity) as avg_qty,
                	avg(l_extendedprice) as avg_price,
                	avg(l_discount) as avg_disc,
                	count(*) as count_order
                from
                	global_temp.lineitem
                where
                	l_shipdate <= date '1998-12-01' - interval '${params(0)}' day
                group by
                	l_returnflag,
                	l_linestatus
                order by
                	l_returnflag,
                  l_linestatus"""
    setGlobalView(desc, desc.lineitem, session, q1)
    // For example, for Q1, params(0) is the interval from the where close
  }

  def execute_Q3(desc: Description, session: SparkSession, params: List[Any]) = {
    assert(params.size == 2)
    val queryNum = 3
    var lineitem = desc.lineitem
    val lineitem_schema = lineitem.schema
    val queryMap = desc.sampleDescription.asInstanceOf[Map[Int, Int]]
    //This is used to compensate when a sample is being used
    var compensate = ""
    if (queryMap != null && queryMap.contains(queryNum)) {
      val new_schema = getSchema(desc.lineitem)
      val sample_index = queryMap(queryNum)
      val rdd = desc.samples(sample_index).asInstanceOf[RDD[Row]]
      val new_lineitem = session.createDataFrame(rdd, new_schema)
      lineitem = new_lineitem
      compensate = " * ratio"
    }
    val q3 = s"""select
                	l_orderkey,
                	sum(l_extendedprice ${compensate} * (1 - l_discount)) as revenue,
                	o_orderdate,
                	o_shippriority
                from
                	global_temp.customer,
                	global_temp.orders,
                	global_temp.lineitem
                where
                	c_mktsegment = '${params(0)}'
                	and c_custkey = o_custkey
                	and l_orderkey = o_orderkey
                	and o_orderdate < date '${params(1)}'
                	and l_shipdate > date '${params(1)}'
                group by
                	l_orderkey,
                	o_orderdate,
                	o_shippriority
                order by
                	revenue desc,
                o_orderdate"""
    setGlobalView(desc, lineitem, session, q3)
    // https://github.com/electrum/tpch-dbgen/blob/master/queries/3.sql
    // using:
    // params(0) as :1
    // params(1) as :2
  }

  def execute_Q5(desc: Description, session: SparkSession, params: List[Any]) = {
    assert(params.size == 2)
    val queryNum = 5
    var lineitem = desc.lineitem
    val lineitem_schema = lineitem.schema
    val queryMap = desc.sampleDescription.asInstanceOf[Map[Int, Int]]
    //This is used to compensate when a sample is being used
    var compensate = ""
    if (queryMap != null && queryMap.contains(queryNum)) {
      val new_schema = getSchema(desc.lineitem)
      val sample_index = queryMap(queryNum)
      val rdd = desc.samples(sample_index).asInstanceOf[RDD[Row]]
      val new_lineitem = session.createDataFrame(rdd, new_schema)
      lineitem = new_lineitem
      compensate = " * ratio"
    }
    val q5 = s"""select
	                n_name,
	                sum(l_extendedprice ${compensate} * (1 - l_discount)) as revenue
                from
	                global_temp.customer,
	                global_temp.orders,
	                global_temp.lineitem,
	                global_temp.supplier,
	                global_temp.nation,
	                global_temp.region
                where
	                c_custkey = o_custkey
	                and l_orderkey = o_orderkey
	                and l_suppkey = s_suppkey
	                and c_nationkey = s_nationkey
                  and s_nationkey = n_nationkey
	                and n_regionkey = r_regionkey
                  and r_name = '${params(0)}'
	                and o_orderdate >= date '${params(1)}'
	                and o_orderdate < date '${params(1)}' + interval '1' year
                group by
	                n_name
                order by
                  revenue desc"""
    setGlobalView(desc, lineitem, session, q5)
  }

  def execute_Q6(desc: Description, session: SparkSession, params: List[Any]) = {
    assert(params.size == 3)
    // TODO: implement
    val queryNum = 6
    var lineitem = desc.lineitem
    val lineitem_schema = lineitem.schema
    val queryMap = desc.sampleDescription.asInstanceOf[Map[Int, Int]]
    //This is used to compensate when a sample is being used
    var compensate = ""
    if (queryMap != null && queryMap.contains(queryNum)) {
      val new_schema = getSchema(desc.lineitem)
      val sample_index = queryMap(queryNum)
      val rdd = desc.samples(sample_index).asInstanceOf[RDD[Row]]
      val new_lineitem = session.createDataFrame(rdd, new_schema)
      lineitem = new_lineitem
      compensate = " * ratio"
    }
    val q5 = s"""select
                	sum(l_extendedprice ${compensate} * l_discount) as revenue
                from
                	global_temp.lineitem
                where
                	l_shipdate >= date '${params(0)}'
                	and l_shipdate < date '${params(0)}' + interval '1' year
                	and l_discount between ${params(1)} - 0.01 and ${params(1)} + 0.01
                and l_quantity < ${params(2)}"""
    setGlobalView(desc, lineitem, session, q5)
  }

  def execute_Q7(desc: Description, session: SparkSession, params: List[Any]) = {
    assert(params.size == 2)
    // TODO: implement
    val queryNum = 7
    var lineitem = desc.lineitem
    val queryMap = desc.sampleDescription.asInstanceOf[Map[Int, Int]]
    //This is used to compensate when a sample is being used
    var compensate = ""
    if (queryMap != null && queryMap.contains(queryNum)) {
      val new_schema = getSchema(desc.lineitem)
      val sample_index = queryMap(queryNum)
      val rdd = desc.samples(sample_index).asInstanceOf[RDD[Row]]
      val new_lineitem = session.createDataFrame(rdd, new_schema)
      lineitem = new_lineitem
      compensate = " * ratio "
    }

    desc.supplier.createOrReplaceTempView("supplier")
    lineitem.createOrReplaceTempView("lineitem")
    desc.orders.createOrReplaceTempView("orders")
    desc.customer.createOrReplaceTempView("customer")
    desc.nation.createOrReplaceTempView("nation")
    val shipping_string = "select " +
      "n1.n_name as supp_nation, n2.n_name as cust_nation, " +
      "year(l_shipdate) as l_year, " +
      "l_extendedprice *  (1 - l_discount) as volume " +
      "from " +
      "supplier, lineitem, orders, customer, nation n1, nation n2 " +
      "where " +
      "s_suppkey = l_suppkey	and o_orderkey = l_orderkey	and c_custkey = o_custkey " +
      "and s_nationkey = n1.n_nationkey	and c_nationkey = n2.n_nationkey " +
      "and (" +
      "(n1.n_name = '" + params(0) + "' and n2.n_name = '" + params(1) +"') " +
      "or (n1.n_name = '" + params(1) + "' and n2.n_name = '" + params(0) + "') " +
      ") " +
      "and l_shipdate between date '1995-01-01' and date '1996-12-31'"
    val shipping = session.sql(shipping_string)
    shipping.createOrReplaceTempView("shipping")
    val sqlDF = session.sql(
      "select " +
        "supp_nation, cust_nation, l_year, sum(volume) as revenue " +
        "from " +
        "shipping " +
        "group by " +
        "supp_nation, cust_nation, l_year " +
        "order by " +
        "supp_nation, cust_nation,	l_year "
    )
    sqlDF.rdd
  }

  def execute_Q9(desc: Description, session: SparkSession, params: List[Any]) = {
    // TODO: implement
    assert(params.size == 1)
    // TODO: implement
    val queryNum = 9
    var lineitem = desc.lineitem
    val queryMap = desc.sampleDescription.asInstanceOf[Map[Int, Int]]
    //This is used to compensate when a sample is being used
    var compensate = ""
    if (queryMap != null && queryMap.contains(queryNum)) {
      val new_schema = getSchema(desc.lineitem)
      val sample_index = queryMap(queryNum)
      val rdd = desc.samples(sample_index).asInstanceOf[RDD[Row]]
      val new_lineitem = session.createDataFrame(rdd, new_schema)
      lineitem = new_lineitem
      compensate = " * ratio"
    }
    desc.part.createOrReplaceTempView("part")
    desc.supplier.createOrReplaceTempView("supplier")
    lineitem.createOrReplaceTempView("lineitem")
    desc.partsupp.createOrReplaceTempView("partsupp")
    desc.orders.createOrReplaceTempView("orders")
    desc.nation.createOrReplaceTempView("nation")

    val profit = session.sql(
      "select " +
        "n_name as nation, year(o_orderdate) as o_year, " +
        "l_extendedprice * (1 - l_discount) - ps_supplycost * l_quantity as amount " +
        "from " +
        "part, supplier, lineitem, partsupp,	orders,	nation " +
        "where " +
        "s_suppkey = l_suppkey and ps_suppkey = l_suppkey and ps_partkey = l_partkey and p_partkey = l_partkey " +
        "and o_orderkey = l_orderkey and s_nationkey = n_nationkey and p_name like '%" + params(0) + "%' "
    )

    profit.createOrReplaceTempView("profit")

    val sqlDF = session.sql(
      "select " +
        "nation, o_year, sum(amount) as sum_profit " +
        "from " +
        "profit " +
        "group by " +
        "nation, o_year " +
        "order by " +
        "nation, o_year desc"
    )
    sqlDF.rdd
  }

  def execute_Q10(desc: Description, session: SparkSession, params: List[Any]) = {
    // TODO: implement
    assert(params.size == 1)
    val queryNum = 10
    var lineitem = desc.lineitem
    val lineitem_schema = lineitem.schema
    val queryMap = desc.sampleDescription.asInstanceOf[Map[Int, Int]]
    //This is used to compensate when a sample is being used
    var compensate = ""
    if (queryMap != null && queryMap.contains(queryNum)) {
      val new_schema = getSchema(desc.lineitem)
      val sample_index = queryMap(queryNum)
      val rdd = desc.samples(sample_index).asInstanceOf[RDD[Row]]
      val new_lineitem = session.createDataFrame(rdd, new_schema)
      lineitem = new_lineitem
      compensate = " * ratio"
    }
    val q6 = s"""select
                	c_custkey,
                	c_name,
                	sum(l_extendedprice ${compensate} * (1 - l_discount)) as revenue,
                	c_acctbal,
                	n_name,
                	c_address,
                	c_phone,
                	c_comment
                from
                	global_temp.customer,
                	global_temp.orders,
                	global_temp.lineitem,
                	global_temp.nation
                where
                	c_custkey = o_custkey
                	and l_orderkey = o_orderkey
                	and o_orderdate >= date '${params(0)}'
                	and o_orderdate < date '${params(0)}' + interval '3' month
                	and l_returnflag = 'R'
                	and c_nationkey = n_nationkey
                group by
                	c_custkey,
                	c_name,
                	c_acctbal,
                	c_phone,
                	n_name,
                	c_address,
                	c_comment
                order by
                  revenue desc"""
    setGlobalView(desc, lineitem, session, q6)
  }

  def execute_Q11(desc: Description, session: SparkSession, params: List[Any]) = {
    // TODO: implement
    assert(params.size == 2)
    val queryNum = 11
    var lineitem = desc.lineitem
    val lineitem_schema = lineitem.schema
    val queryMap = desc.sampleDescription.asInstanceOf[Map[Int, Int]]
    //This is used to compensate when a sample is being used
    var compensate = ""
    if (queryMap != null && queryMap.contains(queryNum)) {
      val new_schema = getSchema(desc.lineitem)
      val sample_index = queryMap(queryNum)
      val rdd = desc.samples(sample_index).asInstanceOf[RDD[Row]]
      val new_lineitem = session.createDataFrame(rdd, new_schema)
      lineitem = new_lineitem
      compensate = " * ratio"
    }
    val q6 = s"""select
                  ps_partkey,
                  sum(ps_supplycost * ps_availqty) as value
                from
                  global_temp.partsupp,
                  global_temp.supplier,
                  global_temp.nation
                where
                  ps_suppkey = s_suppkey
                  and s_nationkey = n_nationkey
                  and n_name = '${params(0)}'
                group by
                  ps_partkey having
                    sum(ps_supplycost * ps_availqty) > (
                      select
                        sum(ps_supplycost * ps_availqty) * ${params(1)}
                      from
                        global_temp.partsupp,
                        global_temp.supplier,
                        global_temp.nation
                      where
                        ps_suppkey = s_suppkey
                        and s_nationkey = n_nationkey
                        and n_name = '${params(0)}'
                    )
                order by
                value desc"""
    setGlobalView(desc, lineitem, session, q6)

  }

  def execute_Q12(desc: Description, session: SparkSession, params: List[Any]) = {
    assert(params.size == 3)
    val queryNum = 12
    val queryMap = desc.sampleDescription.asInstanceOf[Map[Int, Int]]
    var lineitem = desc.lineitem
    //This is used to compensate when a sample is being used
    var compensate = ""
    if (queryMap != null && queryMap.contains(queryNum)) {
      val new_schema = getSchema(desc.lineitem)
      val sample_index = queryMap(queryNum)
      val rdd = desc.samples(sample_index).asInstanceOf[RDD[Row]]
      val new_lineitem = session.createDataFrame(rdd, new_schema)
      lineitem = new_lineitem
      compensate = " * ratio"
    }
    val q6 = s"""select
                  l_shipmode,
                  sum(case
                    when o_orderpriority = '1-URGENT'
                      or o_orderpriority = '2-HIGH'
                      then 1
                    else 0
                  end) as high_line_count,
                  sum(case
                    when o_orderpriority <> '1-URGENT'
                      and o_orderpriority <> '2-HIGH'
                      then 1
                    else 0
                  end) as low_line_count
                from
                  global_temp.orders,
                  global_temp.lineitem
                where
                  o_orderkey = l_orderkey
                  and l_shipmode in ('${params(0)}', '${params(1)}')
                  and l_commitdate < l_receiptdate
                  and l_shipdate < l_commitdate
                  and l_receiptdate >= date '${params(2)}'
                  and l_receiptdate < date '${params(2)}' + interval '1' year
                group by
                  l_shipmode
                order by
                l_shipmode"""
    setGlobalView(desc, lineitem, session, q6)
  }

  def execute_Q17(desc: Description, session: SparkSession, params: List[Any]) = {
    // TODO: implement
    assert(params.size == 2)
    val queryNum = 17
    val queryMap = desc.sampleDescription.asInstanceOf[Map[Int, Int]]
    var lineitem = desc.lineitem
    //This is used to compensate when a sample is being used
    var compensate = ""
    if (queryMap != null && queryMap.contains(queryNum)) {
      val new_schema = getSchema(desc.lineitem)
      val sample_index = queryMap(queryNum)
      val rdd = desc.samples(sample_index).asInstanceOf[RDD[Row]]
      val new_lineitem = session.createDataFrame(rdd, new_schema)
      lineitem = new_lineitem
      compensate = " * ratio"
    }
    val q6 = s"""select
                	sum(l_extendedprice ${compensate}) / 7.0 as avg_yearly
                from
                	global_temp.lineitem,
                	global_temp.part
                where
                	p_partkey = l_partkey
                	and p_brand = '${params(0)}'
                	and p_container = '${params(1)}'
                	and l_quantity < (
                		select
                			0.2 * avg(l_quantity)
                		from
                			global_temp.lineitem
                		where
                			l_partkey = p_partkey
                )"""
    setGlobalView(desc, desc.lineitem, session, q6)
  }

  def execute_Q18(desc: Description, session: SparkSession, params: List[Any]) = {
    assert(params.size == 1)
    val queryNum = 18
    val queryMap = desc.sampleDescription.asInstanceOf[Map[Int, Int]]
    var lineitem = desc.lineitem
    //This is used to compensate when a sample is being used
    var compensate = ""
    if (queryMap != null && queryMap.contains(queryNum)) {
      val new_schema = getSchema(desc.lineitem)
      val sample_index = queryMap(queryNum)
      val rdd = desc.samples(sample_index).asInstanceOf[RDD[Row]]
      val new_lineitem = session.createDataFrame(rdd, new_schema)
      lineitem = new_lineitem
      compensate = " * ratio"
    }
    val q6 = s"""select
                  c_name,
                  c_custkey,
                  o_orderkey,
                  o_orderdate,
                  o_totalprice,
                  sum(l_quantity ${compensate})
                from
                  global_temp.customer,
                  global_temp.orders,
                  global_temp.lineitem
                where
                  o_orderkey in (
                    select
                      l_orderkey
                    from
                      global_temp.lineitem
                    group by
                      l_orderkey having
                        sum(l_quantity) > ${params(0)}
                  )
                  and c_custkey = o_custkey
                  and o_orderkey = l_orderkey
                group by
                  c_name,
                  c_custkey,
                  o_orderkey,
                  o_orderdate,
                  o_totalprice
                order by
                  o_totalprice desc,
                o_orderdate"""
    setGlobalView(desc, lineitem, session, q6)
  }

  def execute_Q19(desc: Description, session: SparkSession, params: List[Any]) = {
    assert(params.size == 6)
    val queryNum = 19
    var lineitem = desc.lineitem
    val lineitem_schema = lineitem.schema
    val queryMap = desc.sampleDescription.asInstanceOf[Map[Int, Int]]
    //This is used to compensate when a sample is being used
    var compensate = ""
    if (queryMap != null && queryMap.contains(queryNum)) {
      val new_schema = getSchema(desc.lineitem)
      val sample_index = queryMap(queryNum)
      val rdd = desc.samples(sample_index).asInstanceOf[RDD[Row]]
      val new_lineitem = session.createDataFrame(rdd, new_schema)
      lineitem = new_lineitem
      compensate = " * ratio"
    }
    val q6 = s"""select
	sum(l_extendedprice ${compensate} * (1 - l_discount)) as revenue
from
	global_temp.lineitem,
	global_temp.part
where
	(
		p_partkey = l_partkey
		and p_brand = '${params(0)}'
		and p_container in ('SM CASE', 'SM BOX', 'SM PACK', 'SM PKG')
		and l_quantity >= ${params(3)} and l_quantity <= ${params(3)} + 10
		and p_size between 1 and 5
		and l_shipmode in ('AIR', 'AIR REG')
		and l_shipinstruct = 'DELIVER IN PERSON'
	)
	or
	(
		p_partkey = l_partkey
		and p_brand = '${params(1)}'
		and p_container in ('MED BAG', 'MED BOX', 'MED PKG', 'MED PACK')
		and l_quantity >= ${params(4)} and l_quantity <= ${params(4)} + 10
		and p_size between 1 and 10
		and l_shipmode in ('AIR', 'AIR REG')
		and l_shipinstruct = 'DELIVER IN PERSON'
	)
	or
	(
		p_partkey = l_partkey
		and p_brand = '${params(2)}'
		and p_container in ('LG CASE', 'LG BOX', 'LG PACK', 'LG PKG')
		and l_quantity >= ${params(5)} and l_quantity <= ${params(5)} + 10
		and p_size between 1 and 15
		and l_shipmode in ('AIR', 'AIR REG')
		and l_shipinstruct = 'DELIVER IN PERSON'
)"""
    setGlobalView(desc, lineitem, session, q6)
  }

  def execute_Q20(desc: Description, session: SparkSession, params: List[Any]) = {
    assert(params.size == 3)
    val queryNum = 20
    var lineitem = desc.lineitem
    val queryMap = desc.sampleDescription.asInstanceOf[Map[Int, Int]]
    //This is used to compensate when a sample is being used
    var compensate = ""
    if (queryMap != null && queryMap.contains(queryNum)) {
      val new_schema = getSchema(desc.lineitem)
      val sample_index = queryMap(queryNum)
      val rdd = desc.samples(sample_index).asInstanceOf[RDD[Row]]
      val new_lineitem = session.createDataFrame(rdd, new_schema)
      lineitem = new_lineitem
      compensate = " * ratio"
    }
    val q6 =
      s"""
         select
         	s_name,
         	s_address
         from
         	global_temp.supplier,
         	global_temp.nation
         where
         	s_suppkey in (
         		select
         			ps_suppkey
         		from
         			global_temp.partsupp
         		where
         			ps_partkey in (
         				select
         					p_partkey
         				from
         					global_temp.part
         				where
         					p_name like '${params(0)}%'
         			)
         			and ps_availqty > (
         				select
         					0.5 * sum(l_quantity)
         				from
         					global_temp.lineitem
         				where
         					l_partkey = ps_partkey
         					and l_suppkey = ps_suppkey
         					and l_shipdate >= date '${params(1)}'
         					and l_shipdate < date '${params(1)}' + interval '1' year
         			)
         	)
         	and s_nationkey = n_nationkey
         	and n_name = '${params(2)}'
         order by
         s_name
       """
    setGlobalView(desc, lineitem, session, q6)
  }

}
