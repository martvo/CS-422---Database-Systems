package sampling

import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.mllib.random.RandomRDDs
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import org.apache.spark.sql.functions._
import org.apache.log4j.Logger
import org.apache.log4j.Level



object Main {
  def main(args: Array[String]) {
    print("yo")
    val pathPrefix = "/home/bjorn/Documents/github.com/DB-Project2/src/main/resources/tpch_parquet_sf1/"
    val conf = new SparkConf().setAppName("app").setMaster("local[*]")
    val sc = SparkContext.getOrCreate(conf)
    val session = SparkSession.builder().getOrCreate();

    sc.setLogLevel("ERROR")

    Logger.getLogger("org").setLevel(Level.OFF)
    Logger.getLogger("akka").setLevel(Level.OFF)


    print("Bjorn")

    var desc = new Description
    desc.lineitem = session.read.parquet(pathPrefix + "lineitem.parquet")
    desc.orders = session.read.parquet(pathPrefix + "order.parquet")
    desc.supplier = session.read.parquet(pathPrefix + "supplier.parquet")
    desc.nation = session.read.parquet(pathPrefix + "nation.parquet")
    desc.region = session.read.parquet(pathPrefix + "region.parquet")
    desc.customer = session.read.parquet(pathPrefix + "customer.parquet")
    desc.part = session.read.parquet(pathPrefix + "part.parquet")
    desc.partsupp =session.read.parquet(pathPrefix + "partsupp.parquet")
    desc.e = 0.1
    desc.ci = 0.95

    //val tmp = Sampler.sample(desc.lineitem, 1000000, desc.e, desc.ci)
    //desc.samples = tmp._1
    //desc.sampleDescription = tmp._2
    print("Hello, I have stopped")

    // check storage usage for samples

    // Execute first query
    Executor.execute_Q9(desc, session, List("bjo"))
  }
}
