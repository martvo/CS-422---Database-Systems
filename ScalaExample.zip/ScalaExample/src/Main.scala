object Main {
  def main(args: Array[String]) {
    // Values    
    val x = "foo"           
    val y = 1
        
    // tuples
    //val xy = (x, y)    
    //val xy = x -> y       
    //val x1 = xy._1
    //val x2 = xy._2
    
    // functions
    //val f = (a: Int) => a * 2        
    //def f1(a: Int): Int = a * 2    
    
    //val f2 = (a: Int, b: Int) => a * b
    //println(f2(2, 3))
    //val f1_2 = (x: (Int, Int)) => x._1 * x._2    
    //println(f1_2((2,3)))
    
    
    // Collections
    //val list = List[Int](1, 2, 3)
    //val empty = List[Int]()
    
    // map
    //val list2 = list.map(a => a * 2)    
    
    // filter
    //val list3 = list.filter(a => a%2 == 0)    
    
    //flatten
    //val list4 = List[List[Int]](List(1), List(2, 3))
    //val list5 = list4.flatten    
    
    // flatMap
    //val list6 = list4.flatMap(x => x)        
    //val list7 = List(1 -> "one", 2 -> "two", 3 -> "three", 3 -> "trois")
    //list7.map(x => x._1)        
    
    // group by
    //val groups = list7.groupBy(x => x._1)
    //println(groups)
    //println(groups.map(x => (x._1, x._2.size)))
    //println(groups.map(x => (x._1, x._2.map(y => y._2))))
  } 
}